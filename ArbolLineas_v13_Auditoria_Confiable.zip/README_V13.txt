ARBOL DE LINEAS V13 - AUDITORIA CONFIABLE
=============================================

OBJETIVO
--------
Reducir falsos positivos sin debilitar los errores que sí tienen
evidencia suficiente.

CAMBIOS PRINCIPALES
-------------------

1. CAMPOS OBLIGATORIOS
Ya NO se marca ERROR solamente porque la API no exponga un campo.

Casos:
- Campo reconocido y presente, pero vacío -> ERROR.
- Campo no reconocido/no expuesto por API -> NO EVALUABLE.
- Campo presente con valor -> OK.

2. FALTA DE NIVELES
LINEA_SIN_CIRCUITOS, CIRCUITO_SIN_TRAMO,
TRAMO_SIN_INSTALACION y VANO_SIN_ACCESORIOS
solo se disparan si /dependants/ respondió correctamente
para ese contenedor.

Una falla de red/API ya no se interpreta como instalación faltante.

3. RELACIONES POR ID
Circuito->Línea, Tramo->Circuito, Vano->Tramo,
Túnel->Tramo y Accesorio->Vano:
solo se comparan si el detalle API expone realmente el campo.

4. HERENCIAS DE NOMBRE
Se normalizan:
- guión normal
- en dash
- em dash
- espacios

Esto evita diferencias tipográficas falsas.

5. REGLAS DE PARSEO MENOS SEGURAS
Los prefijos internos de Vanos/Túneles quedan como ADVERTENCIA,
no ERROR.

6. CONFIANZA
Cada hallazgo tiene:
- ALTA para ERROR
- MEDIA para ADVERTENCIA

7. NO EVALUABLES
El Excel agrega una hoja:
"No Evaluables"

Allí quedan reglas que no pudieron comprobarse porque la API
no expuso el campo esperado. No cuentan como errores.

8. DEDUPLICACIÓN
Hallazgos idénticos no se repiten.

9. EXCLUSIONES SOLICITADAS
No se incluyen:
- NOMBRE_KV_FORMATO
- TRAMO_NOMBRE_SIN_TENSION

EXCEL
-----
Se mantiene en:
Descargas\Reportes_BDATx\

Incluye:
- Resumen
- Catalogo Errores
- Detalles API
- No Evaluables
- Hallazgos
- Arbol Auditado

CREAR EXE
---------
build_windows_v13.bat

RESULTADO
---------
dist\ArbolLineasAuditoriaV13.exe
