
import json
import csv
import queue
import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from urllib.request import Request, urlopen
from urllib.parse import urlencode
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import re

APP_TITLE = "Árbol de relacionamiento de líneas - V13 Auditoría Confiable"
DEFAULT_BASE = "https://activos-tx-prod.appspot.com"
MAX_LEVEL = 4
HTTP_TIMEOUT = 15


# ============================================================
# API
# ============================================================

def get_json(base_url, relative_path, timeout=HTTP_TIMEOUT):
    url = base_url.rstrip("/") + "/" + relative_path.lstrip("/")
    req = Request(
        url,
        headers={
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 ActivosLineas/2.0"
        }
    )
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw), None
    except Exception as exc:
        return None, f"{type(exc).__name__}: {exc}"


def extract_owner(record):
    if not isinstance(record, dict):
        return "", ""

    p = record.get("propietario")

    if isinstance(p, dict):
        pid = p.get("id")
        pname = p.get("name")
    else:
        pid = record.get("propietario_id")
        pname = None

    return (
        "" if pid is None else str(pid),
        "" if pname is None else str(pname)
    )


def get_record(base_url, tipo, item_id):
    errors = []

    for version in ("v2", "v1"):
        data, err = get_json(
            base_url,
            f"api/{version}/{tipo}/{item_id}/"
        )
        if isinstance(data, dict):
            return data, None
        if err:
            errors.append(err)

    return {}, " | ".join(errors)


def get_dependants(base_url, tipo, item_id):
    # Mantener v1 como principal para la jerarquía de líneas
    for version in ("v1", "v2"):
        data, err = get_json(
            base_url,
            f"api/{version}/{tipo}/{item_id}/dependants/"
        )
        if isinstance(data, dict) and isinstance(data.get("results"), list):
            return data["results"], None

    return [], err if 'err' in locals() else None


def parse_dependants(groups):
    out = []

    for group in groups:
        if not isinstance(group, dict):
            continue

        child_type = group.get("reference")
        rows = group.get("result", [])

        if not isinstance(rows, list):
            continue

        for row in rows:
            if not isinstance(row, dict):
                continue

            pid, pname = extract_owner(row)

            out.append({
                "id": "" if row.get("id") is None else str(row.get("id")),
                "name": "" if row.get("name") is None else str(row.get("name")),
                "type": "" if child_type is None else str(child_type),
                "owner_id": pid,
                "owner_name": pname
            })

    return out


# ============================================================
# COLECCIÓN DE LÍNEAS POR PROPIETARIO
# ============================================================

def extract_collection(data):
    if isinstance(data, list):
        return data, None

    if not isinstance(data, dict):
        return [], None

    for key in ("results", "data", "items"):
        if isinstance(data.get(key), list):
            return data[key], data.get("next")

    return [], data.get("next")


def fetch_collection(base_url, relative_path, max_pages=200):
    all_rows = []
    path = relative_path
    seen = set()

    for _ in range(max_pages):
        if not path:
            break

        if path.startswith(base_url.rstrip("/")):
            path = path[len(base_url.rstrip("/")):].lstrip("/")

        if path in seen:
            break
        seen.add(path)

        data, err = get_json(base_url, path)
        if data is None:
            return all_rows, err

        rows, next_path = extract_collection(data)
        all_rows.extend(rows)

        if not next_path:
            break

        path = str(next_path)

    return all_rows, None


def normalize_line(row):
    if not isinstance(row, dict):
        return None

    line_id = row.get("id")
    if line_id is None:
        return None

    pid, pname = extract_owner(row)

    return {
        "id": str(line_id),
        "name": "" if row.get("name") is None else str(row.get("name")),
        "owner_id": pid,
        "owner_name": pname
    }


def find_lines_by_owner(base_url, owner_id, progress=None):
    owner_id = owner_id.strip()

    if not owner_id:
        return [], "Propietario ID vacío."

    candidates = [
        "api/v2/lineas/?" + urlencode({"propietario_id": owner_id}),
        "api/v2/lineas/?" + urlencode({"propietario": owner_id}),
        "api/v2/lineas/?" + urlencode({"propietario__id": owner_id}),
        "api/v1/lineas/?" + urlencode({"propietario_id": owner_id}),
    ]

    # Intentar filtros del servidor
    for path in candidates:
        if progress:
            progress(f"Buscando líneas de {owner_id}...")

        rows, err = fetch_collection(base_url, path)

        normalized = []
        for row in rows:
            item = normalize_line(row)
            if item and item["owner_id"] == owner_id:
                normalized.append(item)

        if normalized:
            unique = {x["id"]: x for x in normalized}
            return sorted(unique.values(), key=lambda x: (x["name"], x["id"])), None

    # Fallback: colección completa y filtro local
    for version in ("v2", "v1"):
        if progress:
            progress(f"Revisando colección completa de líneas {version}...")

        rows, err = fetch_collection(
            base_url,
            f"api/{version}/lineas/"
        )

        normalized = []
        for row in rows:
            item = normalize_line(row)
            if item and item["owner_id"] == owner_id:
                normalized.append(item)

        if normalized:
            unique = {x["id"]: x for x in normalized}
            return sorted(unique.values(), key=lambda x: (x["name"], x["id"])), None

    return [], f"No se encontraron líneas para el propietario {owner_id}."


# ============================================================
# APP
# ============================================================

class App(tk.Tk):

    def __init__(self):
        super().__init__()

        self.title(APP_TITLE)

        try:
            self.state("zoomed")
        except Exception:
            self.geometry("1500x820")

        self.minsize(1100, 650)

        self.base_var = tk.StringVar(value=DEFAULT_BASE)
        self.line_var = tk.StringVar(value="561")
        self.owner_id_var = tk.StringVar(value="")
        self.owner_name_var = tk.StringVar(value="")
        self.search_var = tk.StringVar(value="")
        self.complete_var = tk.BooleanVar(value=False)

        # V11: controles de rendimiento y profundidad
        self.query_mode_var = tk.StringVar(value="Rápida")
        self.depth_var = tk.StringVar(value="Tramos")
        self.workers_var = tk.IntVar(value=8)

        # V11: categorías de auditoría profunda
        self.audit_required_var = tk.BooleanVar(value=True)
        self.audit_nodes_var = tk.BooleanVar(value=True)
        self.audit_naming_var = tk.BooleanVar(value=True)

        self.status_var = tk.StringVar(value="Listo")
        self.count_var = tk.StringVar(value="0 elementos")

        self.q = queue.Queue()
        self.loading = False
        self.cancel_requested = False

        # Líneas actualmente cargadas en el árbol
        self.loaded_line_ids = []
        self.loaded_depth = 0

        # V11: caché de API y estadísticas
        self.api_cache = {}
        self.cache_lock = threading.Lock()
        self.api_request_count = 0
        self.api_cache_hits = 0

        # Detalles recuperados específicamente para auditoría
        self.audit_details = {}

        # V13: evidencia de consultas /dependants/.
        # Permite distinguir "no tiene hijos" de "no fue posible comprobarlo".
        self.dependants_evidence = {}

        # V13: diagnóstico de reglas que no pueden evaluarse con certeza.
        self.not_evaluable = []

        self._style()
        self._ui()

        self.after(100, self._process_events)


    def _style(self):
        s = ttk.Style(self)

        try:
            s.theme_use("vista")
        except Exception:
            pass

        s.configure("Treeview", rowheight=28, font=("Segoe UI", 10))
        s.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))
        s.configure("TLabel", font=("Segoe UI", 10))
        s.configure("TButton", font=("Segoe UI", 10))
        s.configure("TCheckbutton", font=("Segoe UI", 10))


    def _ui(self):

        # ----------------------------------------------------
        # FILA 1
        # ----------------------------------------------------

        r1 = ttk.Frame(self, padding=(10, 10, 10, 4))
        r1.pack(fill="x")

        ttk.Label(r1, text="API base:").grid(row=0, column=0)

        ttk.Entry(
            r1,
            textvariable=self.base_var
        ).grid(
            row=0,
            column=1,
            sticky="ew",
            padx=(8, 20)
        )

        ttk.Label(
            r1,
            text="Línea ID:"
        ).grid(row=0, column=2)

        e_line = ttk.Entry(
            r1,
            textvariable=self.line_var,
            width=12
        )
        e_line.grid(row=0, column=3, padx=(8, 12))
        e_line.bind("<Return>", lambda e: self.load_tree())

        self.btn_load = ttk.Button(
            r1,
            text="Cargar árbol",
            command=self.load_tree
        )
        self.btn_load.grid(row=0, column=4, padx=(0, 8))

        self.btn_cancel = ttk.Button(
            r1,
            text="Cancelar",
            command=self.cancel,
            state="disabled"
        )
        self.btn_cancel.grid(row=0, column=5)

        r1.columnconfigure(1, weight=1)


        # ----------------------------------------------------
        # PROPIETARIO
        # ----------------------------------------------------

        owner_frame = ttk.LabelFrame(
            self,
            text="Propietario de la línea",
            padding=(10, 8, 10, 8)
        )
        owner_frame.pack(fill="x", padx=10, pady=(2, 5))

        ttk.Label(
            owner_frame,
            text="Propietario ID:"
        ).grid(row=0, column=0, sticky="w")

        owner_entry = ttk.Entry(
            owner_frame,
            textvariable=self.owner_id_var,
            width=18
        )
        owner_entry.grid(
            row=0,
            column=1,
            padx=(8, 18),
            sticky="w"
        )
        owner_entry.bind(
            "<Return>",
            lambda e: self.show_owner_lines()
        )

        ttk.Label(
            owner_frame,
            text="Nombre:"
        ).grid(row=0, column=2, sticky="w")

        ttk.Entry(
            owner_frame,
            textvariable=self.owner_name_var,
            state="readonly"
        ).grid(
            row=0,
            column=3,
            sticky="ew",
            padx=(8, 16)
        )

        self.btn_owner_lines = ttk.Button(
            owner_frame,
            text="Líneas del propietario",
            command=self.show_owner_lines
        )
        self.btn_owner_lines.grid(
            row=0,
            column=4,
            padx=(0, 4)
        )

        owner_frame.columnconfigure(3, weight=1)


        # ----------------------------------------------------
        # OPCIONES V11: RENDIMIENTO + AUDITORÍA
        # ----------------------------------------------------

        opt = ttk.LabelFrame(
            self,
            text="Modo de consulta y auditoría",
            padding=(10, 6, 10, 8)
        )
        opt.pack(fill="x", padx=10, pady=(2, 5))

        ttk.Label(opt, text="Modo:").grid(
            row=0, column=0, sticky="w"
        )

        mode_combo = ttk.Combobox(
            opt,
            textvariable=self.query_mode_var,
            values=("Rápida", "Normal", "Auditoría completa"),
            state="readonly",
            width=20
        )
        mode_combo.grid(
            row=0, column=1, sticky="w", padx=(6, 18)
        )

        ttk.Label(opt, text="Profundidad:").grid(
            row=0, column=2, sticky="w"
        )

        depth_combo = ttk.Combobox(
            opt,
            textvariable=self.depth_var,
            values=("Circuitos", "Tramos", "Vanos", "Elementos"),
            state="readonly",
            width=14
        )
        depth_combo.grid(
            row=0, column=3, sticky="w", padx=(6, 18)
        )

        ttk.Label(opt, text="Consultas paralelas:").grid(
            row=0, column=4, sticky="w"
        )

        ttk.Spinbox(
            opt,
            from_=1,
            to=16,
            textvariable=self.workers_var,
            width=5
        ).grid(
            row=0, column=5, sticky="w", padx=(6, 18)
        )

        ttk.Checkbutton(
            opt,
            text="Completar propietario durante la carga",
            variable=self.complete_var
        ).grid(
            row=0, column=6, sticky="w"
        )

        ttk.Checkbutton(
            opt,
            text="Campos obligatorios",
            variable=self.audit_required_var
        ).grid(
            row=1, column=0, columnspan=2,
            sticky="w", pady=(7, 0)
        )

        ttk.Checkbutton(
            opt,
            text="Nodos y continuidad de tramos",
            variable=self.audit_nodes_var
        ).grid(
            row=1, column=2, columnspan=2,
            sticky="w", pady=(7, 0)
        )

        ttk.Checkbutton(
            opt,
            text="Nomenclatura y relacionamiento",
            variable=self.audit_naming_var
        ).grid(
            row=1, column=4, columnspan=2,
            sticky="w", pady=(7, 0)
        )

        ttk.Button(
            opt,
            text="Vaciar caché",
            command=self.clear_api_cache
        ).grid(
            row=1, column=6,
            sticky="e", pady=(7, 0)
        )

        opt.columnconfigure(6, weight=1)


        # ----------------------------------------------------
        # BUSCAR
        # ----------------------------------------------------

        sb = ttk.Frame(self, padding=(10, 2, 10, 7))
        sb.pack(fill="x")

        ttk.Label(sb, text="Buscar:").pack(side="left")

        e_search = ttk.Entry(
            sb,
            textvariable=self.search_var
        )
        e_search.pack(
            side="left",
            fill="x",
            expand=True,
            padx=8
        )
        e_search.bind("<Return>", lambda e: self.find_next())

        ttk.Button(
            sb,
            text="Buscar siguiente",
            command=self.find_next
        ).pack(side="right")


        # ----------------------------------------------------
        # TREE
        # ----------------------------------------------------

        f = ttk.Frame(self, padding=(8, 0, 8, 4))
        f.pack(fill="both", expand=True)

        cols = (
            "nivel",
            "tipo",
            "id",
            "nombre",
            "pid",
            "pname"
        )

        self.tree = ttk.Treeview(
            f,
            columns=cols,
            show="tree headings"
        )

        heads = {
            "#0": "Relación",
            "nivel": "Nivel",
            "tipo": "Tipo",
            "id": "ID",
            "nombre": "Nombre",
            "pid": "Propietario ID",
            "pname": "Propietario"
        }

        for c, h in heads.items():
            self.tree.heading(c, text=h, anchor="center")

        self.tree.column("#0", width=160, stretch=False)
        self.tree.column("nivel", width=70, anchor="center", stretch=False)
        self.tree.column("tipo", width=220)
        self.tree.column("id", width=100, anchor="center")
        self.tree.column("nombre", width=420)
        self.tree.column("pid", width=150, anchor="center")
        self.tree.column("pname", width=360)

        sy = ttk.Scrollbar(
            f,
            orient="vertical",
            command=self.tree.yview
        )
        sx = ttk.Scrollbar(
            f,
            orient="horizontal",
            command=self.tree.xview
        )

        self.tree.configure(
            yscrollcommand=sy.set,
            xscrollcommand=sx.set
        )

        self.tree.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")

        f.rowconfigure(0, weight=1)
        f.columnconfigure(0, weight=1)


        # ----------------------------------------------------
        # STATUS
        # ----------------------------------------------------

        bot = ttk.Frame(self, padding=(10, 4, 10, 8))
        bot.pack(fill="x")

        self.prog = ttk.Progressbar(
            bot,
            mode="indeterminate",
            length=180
        )
        self.prog.pack(side="left", padx=(0, 10))

        ttk.Label(
            bot,
            textvariable=self.status_var
        ).pack(side="left", fill="x", expand=True)

        ttk.Label(
            bot,
            textvariable=self.count_var
        ).pack(side="right")

        self.cache_status_var = tk.StringVar(
            value="API: 0 | Caché: 0"
        )

        ttk.Label(
            bot,
            textvariable=self.cache_status_var
        ).pack(side="right", padx=(12, 0))

        self.btn_audit = ttk.Button(
            bot,
            text="Auditar relacionamiento",
            command=self.run_audit
        )
        self.btn_audit.pack(side="right", padx=(8, 0))

        self.btn_export_excel = ttk.Button(
            bot,
            text="Exportar Excel",
            command=self.export_excel
        )
        self.btn_export_excel.pack(side="right", padx=(8, 0))

        self.btn_export_csv = ttk.Button(
            bot,
            text="Exportar CSV",
            command=self.export_csv
        )
        self.btn_export_csv.pack(side="right", padx=(8, 0))



    # ========================================================
    # V11 - CACHÉ / API / RENDIMIENTO
    # ========================================================

    def _settings_snapshot(self):
        """
        Captura la configuración Tk en el hilo principal.
        Los workers reciben únicamente tipos Python normales.
        """
        return {
            "mode": str(self.query_mode_var.get()),
            "depth": {
                "Circuitos": 1,
                "Tramos": 2,
                "Vanos": 3,
                "Elementos": 4
            }.get(
                self.depth_var.get(),
                2
            ),
            "workers": max(
                1,
                min(
                    16,
                    int(self.workers_var.get())
                )
            ),
            "complete_owner": bool(
                self.complete_var.get()
            )
        }


    def _depth_number(self):
        return {
            "Circuitos": 1,
            "Tramos": 2,
            "Vanos": 3,
            "Elementos": 4
        }.get(
            self.depth_var.get(),
            2
        )


    def _max_workers(self):
        try:
            return max(
                1,
                min(
                    16,
                    int(self.workers_var.get())
                )
            )
        except Exception:
            return 8


    def _update_cache_status(self):
        try:
            self.cache_status_var.set(
                f"API: {self.api_request_count} | "
                f"Caché: {self.api_cache_hits}"
            )
        except Exception:
            pass


    def clear_api_cache(self):
        with self.cache_lock:
            self.api_cache.clear()
            self.api_request_count = 0
            self.api_cache_hits = 0

        self.audit_details = {}
        self._update_cache_status()

        messagebox.showinfo(
            "Caché",
            "La caché de consultas fue eliminada."
        )


    def _cached_json(self, base, path):
        key = (
            base.rstrip("/"),
            path.lstrip("/")
        )

        with self.cache_lock:
            if key in self.api_cache:
                self.api_cache_hits += 1
                data = self.api_cache[key]
                self.q.put(("cache_stats",))
                return data, None

        data, err = get_json(
            base,
            path
        )

        with self.cache_lock:
            self.api_request_count += 1

            if data is not None:
                self.api_cache[key] = data

        self.q.put(("cache_stats",))

        return data, err


    def _get_record_cached(self, base, tipo, item_id):
        errors = []

        for version in ("v2", "v1"):
            data, err = self._cached_json(
                base,
                f"api/{version}/{tipo}/{item_id}/"
            )

            if isinstance(data, dict):
                return data, None

            if err:
                errors.append(err)

        return {}, " | ".join(errors)


    def _get_dependants_cached(self, base, tipo, item_id):
        errors = []

        # Para Línea/Circuito/Tramo se mantiene V1 primero.
        for version in ("v1", "v2"):
            data, err = self._cached_json(
                base,
                f"api/{version}/{tipo}/{item_id}/dependants/"
            )

            if (
                isinstance(data, dict)
                and isinstance(data.get("results"), list)
            ):
                return data["results"], None

            if err:
                errors.append(err)

        return [], " | ".join(errors)


    def _complete_children_details(
        self,
        base,
        children,
        settings
    ):
        """
        Completa nombre/propietario en paralelo únicamente cuando
        el modo seleccionado lo requiere.
        """
        mode = settings.get(
            "mode",
            "Rápida"
        )

        should_complete = (
            mode in ("Normal", "Auditoría completa")
            or bool(
                settings.get(
                    "complete_owner",
                    False
                )
            )
        )

        if not should_complete:
            return children

        pending = []

        for index, child in enumerate(children):
            if (
                child.get("type")
                and child.get("id")
                and (
                    not child.get("name")
                    or not child.get("owner_id")
                    or not child.get("owner_name")
                )
            ):
                pending.append(
                    (
                        index,
                        child["type"],
                        child["id"]
                    )
                )

        if not pending:
            return children

        with ThreadPoolExecutor(
            max_workers=settings.get("workers", 8)
        ) as executor:

            futures = {
                executor.submit(
                    self._get_record_cached,
                    base,
                    tipo,
                    item_id
                ): index
                for index, tipo, item_id in pending
            }

            for future in as_completed(futures):
                index = futures[future]

                try:
                    detail, _ = future.result()
                except Exception:
                    detail = {}

                if not detail:
                    continue

                child = children[index]

                if not child.get("name"):
                    child["name"] = str(
                        detail.get("name", "")
                    )

                pid, pname = extract_owner(
                    detail
                )

                if not child.get("owner_id"):
                    child["owner_id"] = pid

                if not child.get("owner_name"):
                    child["owner_name"] = pname

        return children


    def _worker_lines_bfs(
        self,
        base,
        line_ids,
        settings
    ):
        """
        Carga por niveles (BFS). Todas las consultas /dependants/
        de un mismo nivel se ejecutan en paralelo.
        """
        requested_depth = int(
            settings.get(
                "depth",
                2
            )
        )

        if settings.get("mode") == "Auditoría completa":
            requested_depth = 4

        self.loaded_depth = requested_depth

        current = []

        # Raíces
        with ThreadPoolExecutor(
            max_workers=settings.get("workers", 8)
        ) as executor:

            futures = {
                executor.submit(
                    self._get_record_cached,
                    base,
                    "lineas",
                    line_id
                ): line_id
                for line_id in line_ids
            }

            for future in as_completed(futures):
                if self.cancel_requested:
                    return

                line_id = futures[future]

                try:
                    rec, err = future.result()
                except Exception as exc:
                    rec, err = {}, str(exc)

                if not rec:
                    self.q.put(
                        (
                            "multi_warning",
                            line_id,
                            err or "No fue posible obtener la línea."
                        )
                    )
                    continue

                pid, pname = extract_owner(rec)

                root = {
                    "level": 0,
                    "type": "lineas",
                    "id": str(
                        rec.get(
                            "id",
                            line_id
                        )
                    ),
                    "name": str(
                        rec.get(
                            "name",
                            f"Línea {line_id}"
                        )
                    ),
                    "owner_id": pid,
                    "owner_name": pname
                }

                root_key = f"ROOT_{line_id}"

                self.q.put(
                    (
                        "owner",
                        pid,
                        pname
                    )
                )

                self.q.put(
                    (
                        "add",
                        "",
                        root,
                        root_key
                    )
                )

                current.append(
                    (
                        root,
                        root_key
                    )
                )

        # Niveles 1..profundidad
        for level in range(
            1,
            requested_depth + 1
        ):
            if self.cancel_requested:
                return

            if not current:
                break

            self.q.put(
                (
                    "status",
                    f"Consultando nivel {level} "
                    f"({len(current)} contenedor(es))..."
                )
            )

            parent_results = []

            with ThreadPoolExecutor(
                max_workers=settings.get("workers", 8)
            ) as executor:

                futures = {
                    executor.submit(
                        self._get_dependants_cached,
                        base,
                        parent["type"],
                        parent["id"]
                    ): (
                        parent,
                        parent_key
                    )
                    for parent, parent_key in current
                    if parent.get("type")
                    and parent.get("id")
                }

                for future in as_completed(futures):
                    if self.cancel_requested:
                        return

                    parent, parent_key = futures[future]

                    try:
                        groups, dep_error = future.result()
                        dep_ok = dep_error in (None, "")
                    except Exception as exc:
                        groups = []
                        dep_error = str(exc)
                        dep_ok = False

                    # Guardar evidencia en el hilo principal mediante cola.
                    self.q.put(
                        (
                            "dependants_evidence",
                            parent.get("type", ""),
                            parent.get("id", ""),
                            dep_ok,
                            dep_error or "",
                            groups
                        )
                    )

                    children = parse_dependants(
                        groups
                    )

                    children = self._complete_children_details(
                        base,
                        children,
                        settings
                    )

                    parent_results.append(
                        (
                            parent,
                            parent_key,
                            children
                        )
                    )

            next_current = []

            for parent, parent_key, children in parent_results:

                for index, child in enumerate(children):
                    if self.cancel_requested:
                        return

                    child["level"] = level

                    key = (
                        f"{parent_key}/{level}/"
                        f"{child.get('type','')}/"
                        f"{child.get('id','')}/"
                        f"{index}"
                    )

                    self.q.put(
                        (
                            "add",
                            parent_key,
                            child,
                            key
                        )
                    )

                    if (
                        level < requested_depth
                        and child.get("type")
                        and child.get("id")
                    ):
                        next_current.append(
                            (
                                child,
                                key
                            )
                        )

            current = next_current

        self.q.put(
            (
                "done",
                (
                    "Carga cancelada."
                    if self.cancel_requested
                    else
                    f"Árbol cargado hasta nivel {requested_depth}. "
                    f"Modo: {settings.get('mode', 'Rápida')}."
                )
            )
        )



    # ========================================================
    # CARGA DE ÁRBOL
    # ========================================================

    def load_tree(self):

        if self.loading:
            return

        base = self.base_var.get().strip()
        line_id = self.line_var.get().strip()

        if not base or not line_id:
            messagebox.showwarning(
                "Datos faltantes",
                "Ingrese API base y Línea ID."
            )
            return

        if line_id.startswith("MÚLTIPLES"):
            messagebox.showwarning(
                "Línea ID",
                "Para múltiples líneas utilice "
                "'Líneas del propietario'."
            )
            return

        self.tree.delete(
            *self.tree.get_children()
        )

        self.loaded_line_ids = [line_id]
        self.audit_details = {}
        self.dependants_evidence = {}
        self.not_evaluable = []

        self.owner_id_var.set("")
        self.owner_name_var.set("")

        settings = self._settings_snapshot()

        self._start_loading(
            f"Consultando línea {line_id}..."
        )

        threading.Thread(
            target=self._worker_lines_bfs,
            args=(
                base,
                [line_id],
                settings
            ),
            daemon=True
        ).start()


    # _worker_tree de versiones anteriores reemplazado
    # por _worker_lines_bfs.


    def _expand(self, base, parent, parent_key, complete):

        if self.cancel_requested:
            return

        if parent["level"] >= MAX_LEVEL:
            return

        next_level = parent["level"] + 1

        self.q.put(
            ("status", f'Consultando nivel {next_level}: {parent["name"]}')
        )

        groups, err = get_dependants(
            base,
            parent["type"],
            parent["id"]
        )

        for i, child in enumerate(parse_dependants(groups)):

            if self.cancel_requested:
                return

            child["level"] = next_level

            if (
                complete
                and child["type"]
                and child["id"]
                and (
                    not child["owner_id"]
                    or not child["owner_name"]
                )
            ):
                det, det_err = get_record(
                    base,
                    child["type"],
                    child["id"]
                )

                if det:
                    if not child["name"]:
                        child["name"] = str(det.get("name", ""))

                    x, y = extract_owner(det)

                    if not child["owner_id"]:
                        child["owner_id"] = x

                    if not child["owner_name"]:
                        child["owner_name"] = y

            key = (
                f"{parent_key}/{next_level}/"
                f"{child['type']}/{child['id']}/{i}"
            )

            self.q.put(("add", parent_key, child, key))

            if (
                next_level < MAX_LEVEL
                and child["type"]
                and child["id"]
            ):
                self._expand(
                    base,
                    child,
                    key,
                    complete
                )



    # ========================================================
    # CARGA DE UNA O MÚLTIPLES LÍNEAS
    # ========================================================

    def load_multiple_lines(self, line_ids):
        if self.loading:
            return

        clean_ids = []
        seen = set()

        for value in line_ids:
            line_id = str(value).strip()

            if (
                line_id
                and line_id not in seen
            ):
                seen.add(line_id)
                clean_ids.append(line_id)

        if not clean_ids:
            messagebox.showwarning(
                "Seleccionar líneas",
                "Seleccione al menos una línea."
            )
            return

        self.tree.delete(
            *self.tree.get_children()
        )

        self.loaded_line_ids = clean_ids
        self.audit_details = {}
        self.dependants_evidence = {}
        self.not_evaluable = []

        if len(clean_ids) == 1:
            self.line_var.set(
                clean_ids[0]
            )
        else:
            self.line_var.set(
                f"MÚLTIPLES ({len(clean_ids)})"
            )

        base = self.base_var.get().strip()
        settings = self._settings_snapshot()

        self._start_loading(
            f"Cargando {len(clean_ids)} línea(s)..."
        )

        threading.Thread(
            target=self._worker_lines_bfs,
            args=(
                base,
                clean_ids,
                settings
            ),
            daemon=True
        ).start()


    # ========================================================
    # LÍNEAS DEL PROPIETARIO
    # ========================================================

    def show_owner_lines(self):

        if self.loading:
            return

        base = self.base_var.get().strip()
        owner_id = self.owner_id_var.get().strip()

        if not owner_id:
            messagebox.showwarning(
                "Propietario ID",
                "Ingrese un Propietario ID, por ejemplo P_032."
            )
            return

        self._start_loading(
            f"Buscando líneas del propietario {owner_id}..."
        )

        threading.Thread(
            target=self._worker_owner_lines,
            args=(base, owner_id),
            daemon=True
        ).start()


    def _worker_owner_lines(self, base, owner_id):

        def progress(text):
            self.q.put(("status", text))

        rows, err = find_lines_by_owner(
            base,
            owner_id,
            progress
        )

        if self.cancel_requested:
            self.q.put(("done", "Búsqueda cancelada."))
            return

        self.q.put(
            ("owner_lines", owner_id, rows, err)
        )


    def _open_owner_lines(self, owner_id, rows, err):

        self._finish_loading()

        if not rows:
            messagebox.showwarning(
                "Líneas del propietario",
                err or f"No se encontraron líneas para {owner_id}."
            )
            return

        win = tk.Toplevel(self)
        win.title(f"Líneas del propietario {owner_id}")
        win.geometry("1050x600")
        win.minsize(800, 450)
        win.transient(self)

        head = ttk.Frame(win, padding=(10, 10, 10, 6))
        head.pack(fill="x")

        ttk.Label(
            head,
            text=f"Propietario ID: {owner_id}",
            font=("Segoe UI", 11, "bold")
        ).pack(side="left")

        ttk.Label(
            head,
            text=f"{len(rows)} línea(s)"
        ).pack(side="right")

        body = ttk.Frame(win, padding=(10, 0, 10, 6))
        body.pack(fill="both", expand=True)

        cols = ("id", "nombre", "pid", "pname")

        tv = ttk.Treeview(
            body,
            columns=cols,
            show="headings",
            selectmode="extended"
        )

        tv.heading("id", text="Línea ID")
        tv.heading("nombre", text="Nombre")
        tv.heading("pid", text="Propietario ID")
        tv.heading("pname", text="Propietario")

        tv.column("id", width=120, anchor="center", stretch=False)
        tv.column("nombre", width=380)
        tv.column("pid", width=150, anchor="center", stretch=False)
        tv.column("pname", width=350)

        sy = ttk.Scrollbar(
            body,
            orient="vertical",
            command=tv.yview
        )

        tv.configure(yscrollcommand=sy.set)

        tv.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")

        body.rowconfigure(0, weight=1)
        body.columnconfigure(0, weight=1)

        for line in rows:
            tv.insert(
                "",
                "end",
                values=(
                    line["id"],
                    line["name"],
                    line["owner_id"],
                    line["owner_name"]
                )
            )

        actions = ttk.Frame(
            win,
            padding=(10, 4, 10, 10)
        )
        actions.pack(fill="x")

        selection_info = tk.StringVar(
            value="0 línea(s) seleccionada(s)"
        )

        ttk.Label(
            actions,
            textvariable=selection_info
        ).pack(side="left")

        def update_selection_info(event=None):
            selection_info.set(
                f"{len(tv.selection())} línea(s) seleccionada(s)"
            )

        def select_all():
            items = tv.get_children("")
            tv.selection_set(items)
            update_selection_info()

        def clear_selection():
            selected = tv.selection()
            if selected:
                tv.selection_remove(selected)
            update_selection_info()

        def load_selected():
            selected = tv.selection()

            if not selected:
                messagebox.showinfo(
                    "Seleccionar",
                    "Seleccione una o más líneas."
                )
                return

            selected_ids = []

            for item in selected:
                values = tv.item(item, "values")
                if values:
                    selected_ids.append(str(values[0]))

            win.destroy()
            self.load_multiple_lines(selected_ids)

        ttk.Button(
            actions,
            text="Seleccionar todas",
            command=select_all
        ).pack(side="left", padx=(12, 0))

        ttk.Button(
            actions,
            text="Limpiar selección",
            command=clear_selection
        ).pack(side="left", padx=(8, 0))

        ttk.Button(
            actions,
            text="Cargar seleccionadas",
            command=load_selected
        ).pack(side="right")

        ttk.Button(
            actions,
            text="Cerrar",
            command=win.destroy
        ).pack(side="right", padx=(0, 8))

        tv.bind(
            "<<TreeviewSelect>>",
            update_selection_info
        )

        tv.bind(
            "<Double-1>",
            lambda e: load_selected()
        )


    # ========================================================
    # ESTADO
    # ========================================================

    def _start_loading(self, text):
        self.loading = True
        self.cancel_requested = False

        self.btn_load.config(state="disabled")
        self.btn_owner_lines.config(state="disabled")
        self.btn_cancel.config(state="normal")

        self.prog.start(12)
        self.status_var.set(text)


    def cancel(self):
        if self.loading:
            self.cancel_requested = True
            self.status_var.set("Cancelando...")


    def _finish_loading(self):
        self.loading = False

        self.prog.stop()

        self.btn_load.config(state="normal")
        self.btn_owner_lines.config(state="normal")
        self.btn_cancel.config(state="disabled")


    def _process_events(self):

        try:
            while True:
                event = self.q.get_nowait()
                kind = event[0]

                if kind == "status":
                    self.status_var.set(event[1])

                elif kind == "cache_stats":
                    self._update_cache_status()

                elif kind == "dependants_evidence":
                    _, tipo, item_id, ok, error_text, groups = event

                    child_types = []
                    if isinstance(groups, list):
                        for group in groups:
                            if isinstance(group, dict):
                                ref = group.get("reference")
                                if ref:
                                    child_types.append(str(ref))

                    self.dependants_evidence[
                        (str(tipo), str(item_id))
                    ] = {
                        "ok": bool(ok),
                        "error": str(error_text or ""),
                        "child_types": child_types
                    }

                elif kind == "owner":
                    _, pid, pname = event
                    self.owner_id_var.set(pid)
                    self.owner_name_var.set(pname)

                elif kind == "add":
                    _, parent, node, key = event

                    labels = {
                        0: "Línea",
                        1: "Circuito",
                        2: "Tramo",
                        3: "Vano",
                        4: "Elemento"
                    }

                    self.tree.insert(
                        "" if parent == "" else parent,
                        "end",
                        iid=key,
                        text=labels.get(node["level"], f"Nivel {node['level']}"),
                        values=(
                            node["level"],
                            node["type"],
                            node["id"],
                            node["name"],
                            node["owner_id"],
                            node["owner_name"]
                        ),
                        open=node["level"] <= 1
                    )

                    self.count_var.set(
                        f"{self._count_items()} elementos"
                    )

                elif kind == "fatal":
                    self._finish_loading()
                    messagebox.showerror("Error", event[1])

                elif kind == "done":
                    self._finish_loading()
                    self.status_var.set(event[1])

                elif kind == "multi_warning":
                    _, line_id, message = event
                    self.status_var.set(
                        f"Advertencia línea {line_id}: {message}"
                    )

                elif kind == "audit_details_ready":
                    _, details = event
                    self._finish_audit_after_details(
                        details
                    )

                elif kind == "owner_lines":
                    _, owner_id, rows, err = event
                    self._open_owner_lines(owner_id, rows, err)

        except queue.Empty:
            pass

        self.after(100, self._process_events)



    # ========================================================
    # AUDITORÍA DE CALIDAD / RELACIONAMIENTO
    # ========================================================

    def _tree_records_for_audit(self):
        records = []

        def walk(parent=""):
            for item in self.tree.get_children(parent):
                values = self.tree.item(item, "values")
                parent_item = self.tree.parent(item)
                parent_values = self.tree.item(parent_item, "values") if parent_item else ()

                records.append({
                    "iid": item,
                    "parent_iid": parent_item,
                    "nivel": int(values[0]) if len(values) > 0 and str(values[0]).strip() else None,
                    "tipo": str(values[1]) if len(values) > 1 else "",
                    "id": str(values[2]) if len(values) > 2 else "",
                    "nombre": str(values[3]) if len(values) > 3 else "",
                    "propietario_id": str(values[4]) if len(values) > 4 else "",
                    "propietario": str(values[5]) if len(values) > 5 else "",
                    "parent_tipo": str(parent_values[1]) if len(parent_values) > 1 else "",
                    "parent_id": str(parent_values[2]) if len(parent_values) > 2 else "",
                    "parent_nombre": str(parent_values[3]) if len(parent_values) > 3 else "",
                })
                walk(item)

        walk()
        return records

    @staticmethod
    def _normalize_name(text):
        return " ".join(str(text or "").strip().upper().split())

    @staticmethod
    def _name_is_uppercase_conservative(name):
        if not name:
            return True
        test = str(name).replace("kV", "KV").replace("kA", "KA").replace("kW", "KW").replace("kVA", "KVA")
        letters = "".join(ch for ch in test if ch.isalpha())
        return letters == letters.upper()

    # ========================================================
    # V11 - AUDITORÍA PROFUNDA
    # ========================================================

    @staticmethod
    def _norm_field_name(value):
        return re.sub(
            r"[^a-z0-9]",
            "",
            str(value or "").lower()
        )


    def _field_probe(
        self,
        record,
        candidates
    ):
        """
        Retorna (present, value, actual_key).

        Regla V13:
        - present=False: la API no expuso ningún campo compatible.
          NO se puede afirmar que falta el dato en plataforma.
        - present=True y value vacío: evidencia suficiente para ERROR.
        """
        if not isinstance(record, dict):
            return False, None, ""

        wanted = {
            self._norm_field_name(x)
            for x in candidates
        }

        for key, value in record.items():
            if self._norm_field_name(key) in wanted:
                return True, value, str(key)

        return False, None, ""


    def _field_value(
        self,
        record,
        candidates
    ):
        present, value, _ = self._field_probe(
            record,
            candidates
        )
        return value if present else None


    @staticmethod
    def _value_id(value):
        if value is None:
            return ""

        if isinstance(value, dict):
            for key in (
                "id",
                "pk",
                "value"
            ):
                if value.get(key) is not None:
                    return str(value.get(key))

            return ""

        if isinstance(value, list):
            if not value:
                return ""

            return App._value_id(
                value[0]
            )

        text = str(value).strip()

        return text


    @staticmethod
    def _value_name(value):
        if isinstance(value, dict):
            for key in (
                "name",
                "nombre",
                "label"
            ):
                if value.get(key):
                    return str(value.get(key))

        return ""


    def _prepare_audit_details_worker(
        self,
        base,
        records,
        workers
    ):
        unique = {}

        for record in records:
            tipo = record.get("tipo", "")
            item_id = record.get("id", "")

            if tipo and item_id:
                unique[
                    (
                        tipo,
                        item_id
                    )
                ] = True

        details = {}

        self.q.put(
            (
                "status",
                f"Auditoría detallada: "
                f"{len(unique)} registros..."
            )
        )

        with ThreadPoolExecutor(
            max_workers=workers
        ) as executor:

            futures = {
                executor.submit(
                    self._get_record_cached,
                    base,
                    tipo,
                    item_id
                ): (
                    tipo,
                    item_id
                )
                for tipo, item_id in unique
            }

            for future in as_completed(futures):
                if self.cancel_requested:
                    return

                key = futures[future]

                try:
                    detail, _ = future.result()
                except Exception:
                    detail = {}

                details[key] = detail or {}

        self.q.put(
            (
                "audit_details_ready",
                details
            )
        )


    def _enrich_tree_from_audit_details(self):
        """
        Completa en el árbol Nombre/Propietario ID/Propietario usando
        el detalle individual recuperado durante la auditoría.
        """
        updated = 0

        def walk(parent=""):
            nonlocal updated

            for item in self.tree.get_children(parent):
                values = list(self.tree.item(item, "values"))

                if len(values) >= 6:
                    tipo = str(values[1] or "")
                    item_id = str(values[2] or "")

                    detail = self.audit_details.get(
                        (tipo, item_id),
                        {}
                    )

                    if isinstance(detail, dict) and detail:
                        if not str(values[3] or "").strip():
                            detail_name = detail.get("name")
                            if detail_name is not None:
                                values[3] = str(detail_name)

                        detail_owner_id, detail_owner_name = extract_owner(detail)

                        if not str(values[4] or "").strip() and detail_owner_id:
                            values[4] = detail_owner_id

                        if not str(values[5] or "").strip() and detail_owner_name:
                            values[5] = detail_owner_name

                        self.tree.item(
                            item,
                            values=tuple(values)
                        )

                        if detail_owner_id or detail_owner_name:
                            updated += 1

                walk(item)

        walk()
        return updated


    def _append_deep_audit_findings(
        self,
        findings,
        records
    ):
        """
        Añade validaciones que requieren el detalle individual
        recuperado desde /api/v2|v1/{tipo}/{id}/.
        """
        if not self.audit_details:
            return findings

        by_iid = {
            r["iid"]: r
            for r in records
            if r.get("iid")
        }

        children = defaultdict(list)

        for r in records:
            children[
                r.get(
                    "parent_iid",
                    ""
                )
            ].append(r)

        def add(
            severity,
            code_value,
            record,
            message,
            rule
        ):
            findings.append({
                "severidad": severity,
                "codigo": code_value,
                "nivel": record.get("nivel", ""),
                "tipo": record.get("tipo", ""),
                "id": record.get("id", ""),
                "nombre": record.get("nombre", ""),
                "propietario_id": record.get("propietario_id", ""),
                "padre": (
                    f'{record.get("parent_tipo","")} '
                    f'{record.get("parent_id","")} '
                    f'{record.get("parent_nombre","")}'
                ).strip(),
                "mensaje": message,
                "regla": rule,
                "confianza": "ALTA" if severity == "ERROR" else "MEDIA",
                "iid": record.get("iid", "")
            })

        # ----------------------------------------------
        # Reglas generales del Nombre según manual
        # ----------------------------------------------
        if self.audit_naming_var.get():
            for r in records:
                name = str(r.get("nombre", "") or "")
                tipo = r.get("tipo", "").strip().lower()

                if self._contains_bad_decimal_comma(name):
                    add(
                        "ERROR",
                        "NOMBRE_DECIMAL_CON_COMA",
                        r,
                        "El Nombre contiene un valor decimal expresado con coma.",
                        "El manual exige punto para valores decimales."
                    )

        # ----------------------------------------------
        # Campos obligatorios según tipo
        # ----------------------------------------------
        if self.audit_required_var.get():

            required = {
                "lineas": [
                    ("LINEA_SIN_DECRETO_NUP", ("decreto","nup","decreto_nup","decretonup","decreto_id","nup_id"), "Decreto/NUP"),
                    ("LINEA_SIN_SISTEMA_ELECTRICO", ("sistema_electrico","sistemaelectrico","sistema","sistema_electrico_id"), "Sistema eléctrico"),
                    ("LINEA_SIN_CATEGORIA_VU", ("categoria_vu","categoriavu","categoria_vida_util","categoria"), "Categoría VU"),
                ],
                "circuitos": [
                    ("CIRCUITO_SIN_LINEA_CAMPO", ("linea","linea_id","lineaid"), "Línea"),
                    ("CIRCUITO_SIN_DECRETO_NUP", ("decreto","nup","decreto_nup","decretonup","decreto_id","nup_id"), "Decreto/NUP"),
                    ("CIRCUITO_SIN_CATEGORIA_VU", ("categoria_vu","categoriavu","categoria_vida_util","categoria"), "Categoría VU"),
                ],
                "tramos": [
                    (
                        "TRAMO_SIN_CIRCUITO_CAMPO",
                        ("circuito", "circuito_id", "circuitoid"),
                        "Circuito"
                    ),
                    (
                        "TRAMO_SIN_NODO1",
                        ("nodo1", "nodo_1", "nodo1_id", "nodoorigen"),
                        "Nodo 1"
                    ),
                    (
                        "TRAMO_SIN_NODO2",
                        ("nodo2", "nodo_2", "nodo2_id", "nododestino"),
                        "Nodo 2"
                    ),
                    (
                        "TRAMO_SIN_DECRETO_NUP",
                        (
                            "decreto",
                            "nup",
                            "decreto_nup",
                            "decretonup",
                            "decreto_id",
                            "nup_id"
                        ),
                        "Decreto/NUP"
                    ),
                    (
                        "TRAMO_SIN_CATEGORIA_VU",
                        (
                            "categoria_vu",
                            "categoriavu",
                            "categoria_vida_util",
                            "categoria"
                        ),
                        "Categoría VU"
                    ),
                ],
                "vanos": [
                    (
                        "VANO_SIN_TRAMO_CAMPO",
                        ("tramo", "tramo_id", "tramoid"),
                        "Tramo"
                    ),
                    (
                        "VANO_SIN_NODO1",
                        ("nodo1", "nodo_1", "nodo1_id", "nodoorigen"),
                        "Nodo 1"
                    ),
                    (
                        "VANO_SIN_NODO2",
                        ("nodo2", "nodo_2", "nodo2_id", "nododestino"),
                        "Nodo 2"
                    ),
                    (
                        "VANO_SIN_DECRETO_NUP",
                        (
                            "decreto",
                            "nup",
                            "decreto_nup",
                            "decretonup",
                            "decreto_id",
                            "nup_id"
                        ),
                        "Decreto/NUP"
                    ),
                    (
                        "VANO_SIN_CATEGORIA_VU",
                        (
                            "categoria_vu",
                            "categoriavu",
                            "categoria_vida_util",
                            "categoria"
                        ),
                        "Categoría VU"
                    ),
                ],
                "tuneles": [
                    ("TUNEL_SIN_TRAMO_CAMPO", ("tramo","tramo_id","tramoid"), "Tramo"),
                    ("TUNEL_SIN_NODO1", ("nodo1","nodo_1","nodo1_id","nodoorigen"), "Nodo 1"),
                    ("TUNEL_SIN_NODO2", ("nodo2","nodo_2","nodo2_id","nododestino"), "Nodo 2"),
                    ("TUNEL_SIN_DECRETO_NUP", ("decreto","nup","decreto_nup","decretonup","decreto_id","nup_id"), "Decreto/NUP"),
                    ("TUNEL_SIN_CATEGORIA_VU", ("categoria_vu","categoriavu","categoria_vida_util","categoria"), "Categoría VU"),
                ],
                "accesorios-vanos": [
                    (
                        "ACCESORIO_SIN_VANO_CAMPO",
                        ("vano", "vano_id", "vanoid"),
                        "Vano"
                    ),
                    (
                        "ACCESORIO_SIN_DECRETO_NUP",
                        (
                            "decreto",
                            "nup",
                            "decreto_nup",
                            "decretonup"
                        ),
                        "Decreto/NUP"
                    ),
                    (
                        "ACCESORIO_SIN_CATEGORIA_VU",
                        (
                            "categoria_vu",
                            "categoriavu",
                            "categoria_vida_util",
                            "categoria"
                        ),
                        "Categoría VU"
                    ),
                ]
            }

            for r in records:
                tipo = r["tipo"].strip().lower()
                detail = self.audit_details.get(
                    (
                        r["tipo"],
                        r["id"]
                    ),
                    {}
                )

                if not detail:
                    continue

                for (
                    error_code,
                    candidates,
                    label
                ) in required.get(
                    tipo,
                    []
                ):
                    present, value, actual_key = self._field_probe(
                        detail,
                        candidates
                    )

                    if not present:
                        # La API puede usar otro nombre de campo o no exponerlo.
                        # No se convierte una limitación de API en error de datos.
                        self.not_evaluable.append({
                            "codigo": error_code,
                            "tipo": r.get("tipo", ""),
                            "id": r.get("id", ""),
                            "nombre": r.get("nombre", ""),
                            "motivo": (
                                f'La API no expuso un campo reconocible para "{label}".'
                            )
                        })

                    elif self._is_empty_api_value(value):
                        add(
                            "ERROR",
                            error_code,
                            r,
                            (
                                f'El campo obligatorio "{label}" '
                                f'({actual_key}) está presente pero vacío.'
                            ),
                            (
                                f"Validación de campo obligatorio "
                                f"para {tipo}."
                            )
                        )

        # ----------------------------------------------
        # Relación por IDs de detalle
        # ----------------------------------------------
        if self.audit_naming_var.get():

            for r in records:
                parent = by_iid.get(
                    r.get(
                        "parent_iid",
                        ""
                    )
                )

                if not parent:
                    continue

                detail = self.audit_details.get(
                    (
                        r["tipo"],
                        r["id"]
                    ),
                    {}
                )

                if not detail:
                    continue

                tipo = r["tipo"].strip().lower()

                if tipo == "circuitos":
                    line_present, line_value, _ = self._field_probe(
                        detail,
                        ("linea", "linea_id", "lineaid")
                    )
                    line_id = self._value_id(line_value)

                    if (
                        line_present
                        and line_id
                        and parent["tipo"].strip().lower() == "lineas"
                        and line_id != parent["id"]
                    ):
                        add(
                            "ERROR",
                            "CIRCUITO_LINEA_ID_NO_COINCIDE",
                            r,
                            f'El detalle del Circuito apunta a la Línea {line_id}, pero en el árbol está bajo la Línea {parent["id"]}.',
                            "El campo Línea del Circuito debe coincidir con su Línea padre."
                        )

                elif tipo == "tramos":
                    circuit_present, circuit_value, _ = self._field_probe(
                        detail,
                        (
                            "circuito",
                            "circuito_id",
                            "circuitoid"
                        )
                    )

                    circuit_id = self._value_id(
                        circuit_value
                    )

                    if (
                        circuit_present
                        and circuit_id
                        and parent["tipo"].strip().lower() == "circuitos"
                        and circuit_id != parent["id"]
                    ):
                        add(
                            "ERROR",
                            "TRAMO_CIRCUITO_ID_NO_COINCIDE",
                            r,
                            (
                                f'El detalle del Tramo apunta al Circuito '
                                f'{circuit_id}, pero en el árbol está bajo '
                                f'el Circuito {parent["id"]}.'
                            ),
                            (
                                "El campo Circuito del Tramo debe coincidir "
                                "con su Circuito padre."
                            )
                        )

                elif tipo == "vanos":
                    tramo_present, tramo_value, _ = self._field_probe(
                        detail,
                        (
                            "tramo",
                            "tramo_id",
                            "tramoid"
                        )
                    )

                    tramo_id = self._value_id(
                        tramo_value
                    )

                    if (
                        tramo_present
                        and tramo_id
                        and parent["tipo"].strip().lower() == "tramos"
                        and tramo_id != parent["id"]
                    ):
                        add(
                            "ERROR",
                            "VANO_TRAMO_ID_NO_COINCIDE",
                            r,
                            (
                                f'El detalle del Vano apunta al Tramo '
                                f'{tramo_id}, pero en el árbol está bajo '
                                f'el Tramo {parent["id"]}.'
                            ),
                            (
                                "El campo Tramo del Vano debe coincidir "
                                "con su Tramo padre."
                            )
                        )

                elif tipo == "tuneles":
                    tramo_value = self._field_value(
                        detail,
                        ("tramo", "tramo_id", "tramoid")
                    )
                    tramo_id = self._value_id(tramo_value)

                    if (
                        tramo_id
                        and parent["tipo"].strip().lower() == "tramos"
                        and tramo_id != parent["id"]
                    ):
                        add(
                            "ERROR",
                            "TUNEL_TRAMO_ID_NO_COINCIDE",
                            r,
                            f'El detalle del Túnel apunta al Tramo {tramo_id}, pero en el árbol está bajo el Tramo {parent["id"]}.',
                            "El campo Tramo del Túnel debe coincidir con su Tramo padre."
                        )

                elif tipo in {
                    "accesorios-vanos",
                    "accesorios_vanos",
                    "accesoriosvanos"
                }:
                    vano_present, vano_value, _ = self._field_probe(
                        detail,
                        (
                            "vano",
                            "vano_id",
                            "vanoid"
                        )
                    )

                    vano_id = self._value_id(
                        vano_value
                    )

                    if (
                        vano_present
                        and vano_id
                        and parent["tipo"].strip().lower() == "vanos"
                        and vano_id != parent["id"]
                    ):
                        add(
                            "ERROR",
                            "ACCESORIO_VANO_ID_NO_COINCIDE",
                            r,
                            (
                                f'El accesorio apunta al Vano {vano_id}, '
                                f'pero está relacionado bajo el Vano '
                                f'{parent["id"]}.'
                            ),
                            (
                                "El campo Vano del accesorio debe coincidir "
                                "con su Vano padre."
                            )
                        )

        # ----------------------------------------------
        # Estructura formal del Nombre según tipo
        # ----------------------------------------------
        if self.audit_naming_var.get():
            for r in records:
                tipo = r["tipo"].strip().lower()
                name = str(r["nombre"] or "")
                upper = name.upper()
                parent = by_iid.get(r.get("parent_iid", ""))

                if tipo == "lineas":
                    if not self._has_endpoint_separator(name):
                        add("ERROR","LINEA_NOMBRE_SIN_SEPARADOR",r,
                            "El Nombre de la Línea no presenta el separador ' - ' entre extremos.",
                            "Formato LT: extremo inicial - extremo final + tensión.")

                    if not self._extract_nominal_voltage(name):
                        add("ERROR","LINEA_NOMBRE_SIN_TENSION",r,
                            "El Nombre de la Línea no contiene una tensión nominal en formato kV.",
                            "Formato LT exige nivel de tensión.")

                    if self._contains_forbidden_se_prefix_in_line_name(name):
                        add("ERROR","LINEA_NOMBRE_CONTIENE_SE",r,
                            "El Nombre de Línea contiene 'S/E'.",
                            "Los nombres de los extremos deben escribirse sin prefijo S/E.")

                elif tipo == "circuitos":
                    if not self._extract_final_circuit_token(name):
                        add("ERROR","CIRCUITO_SIN_NUMERO_NOMBRE",r,
                            "El Nombre del Circuito no termina en Cn.",
                            "Formato CTO exige Número Circuito.")

                    if parent and parent["tipo"].strip().lower() == "lineas":
                        inherited = self._strip_known_prefix(parent["nombre"], "LT")
                        body = self._strip_known_prefix(name, "CTO")
                        body = re.sub(r"\s+C\d+\s*$", "", body, flags=re.IGNORECASE).strip()

                        if self._canonical_name(inherited) != self._canonical_name(body):
                            add("ERROR","CIRCUITO_HERENCIA_LINEA_NO_COINCIDE",r,
                                "La parte heredada del Nombre del Circuito no coincide con el Nombre de la Línea padre.",
                                "Formato CTO exige heredar el Nombre de la Línea.")

                elif tipo == "tramos":
                    if not self._has_endpoint_separator(name):
                        add("ERROR","TRAMO_NOMBRE_SIN_SEPARADOR",r,
                            "El Nombre del Tramo no presenta ' - ' entre extremos.",
                            "Formato TMO exige Extremo 1 - Extremo 2.")

                    if not self._extract_final_circuit_token(name):
                        add("ERROR","TRAMO_NOMBRE_SIN_CIRCUITO",r,
                            "El Nombre del Tramo no termina en Cn.",
                            "Formato TMO exige Nombre Circuito.")

                    tramo_children = children.get(r["iid"], [])
                    has_vano = any(c["tipo"].strip().lower() == "vanos" for c in tramo_children)
                    has_tunnel = any(c["tipo"].strip().lower() == "tuneles" for c in tramo_children)

                    if has_vano and has_tunnel:
                        add("ERROR","TRAMO_MEZCLA_VANO_TUNEL",r,
                            "El mismo Tramo contiene Vanos y Túneles, mezclando parte aérea y subterránea.",
                            "El cambio aéreo↔soterrado debe generar distintos Tramos.")

                elif tipo == "vanos":
                    if ":" not in name:
                        add("ERROR","VANO_NOMBRE_SIN_DOS_PUNTOS",r,
                            "El Nombre del Vano no contiene ':' entre sus extremos.",
                            "Formato VN exige separador ':' entre estructuras.")

                    matches = re.findall(r"(?<![A-Z0-9])(TOR|POR|POS|ML)\s+[^:\s]+", upper)
                    if len(matches) < 2:
                        add("ADVERTENCIA","VANO_EXTREMO_PREFIJO_INVALIDO",r,
                            "No se identifican dos extremos con prefijos TOR, POR, POS o ML.",
                            "Formato VN exige prefijos de estructura válidos.")

                    if not self._extract_final_circuit_token(name):
                        add("ERROR","VANO_SIN_CIRCUITO_NOMBRE",r,
                            "El Nombre del Vano no termina en Cn.",
                            "Formato VN exige Nombre Circuito.")

                elif tipo == "tuneles":
                    if ":" not in name:
                        add("ERROR","TUNEL_NOMBRE_SIN_DOS_PUNTOS",r,
                            "El Nombre del Túnel no contiene ':' entre sus extremos.",
                            "Formato TN exige separador ':' entre extremos.")

                    matches = re.findall(r"(?<![A-Z0-9])(CAM|PM)\s+[^:\s]+", upper)
                    if len(matches) < 2:
                        add("ADVERTENCIA","TUNEL_EXTREMO_PREFIJO_INVALIDO",r,
                            "No se identifican dos extremos con prefijos CAM o PM.",
                            "Formato TN exige CAM o PM en sus extremos.")

                    if not self._extract_final_circuit_token(name):
                        add("ERROR","TUNEL_SIN_CIRCUITO_NOMBRE",r,
                            "El Nombre del Túnel no termina en Cn.",
                            "Formato TN exige Nombre Circuito.")

                elif tipo in {"accesorios-vanos","accesorios_vanos","accesoriosvanos"}:
                    if parent and parent["tipo"].strip().lower() == "vanos":
                        expected = "ACC " + str(parent["nombre"] or "").strip()
                        if self._canonical_name(name) != self._canonical_name(expected):
                            add("ERROR","ACCESORIO_HERENCIA_VANO_NO_COINCIDE",r,
                                "El Nombre del Accesorio no corresponde a 'ACC ' + Nombre del Vano padre.",
                                "Formato ACC exige herencia exacta del Nombre del Vano.")

        # ----------------------------------------------
        # Nodos y continuidad de Tramos
        # ----------------------------------------------
        if self.audit_nodes_var.get():

            node_info = {}

            for r in records:
                if r["tipo"].strip().lower() != "tramos":
                    continue

                detail = self.audit_details.get(
                    (
                        r["tipo"],
                        r["id"]
                    ),
                    {}
                )

                if not detail:
                    continue

                n1_value = self._field_value(
                    detail,
                    (
                        "nodo1",
                        "nodo_1",
                        "nodo1_id",
                        "nodoorigen"
                    )
                )

                n2_value = self._field_value(
                    detail,
                    (
                        "nodo2",
                        "nodo_2",
                        "nodo2_id",
                        "nododestino"
                    )
                )

                n1 = self._value_id(
                    n1_value
                )

                n2 = self._value_id(
                    n2_value
                )

                node_info[
                    r["iid"]
                ] = (
                    n1,
                    n2
                )

                if n1 and n2 and n1 == n2:
                    add(
                        "ERROR",
                        "TRAMO_NODOS_IGUALES",
                        r,
                        (
                            f"El Tramo posee el mismo Nodo 1 y Nodo 2 "
                            f"({n1})."
                        ),
                        (
                            "Los extremos de un Tramo deben representar "
                            "dos puntos distintos."
                        )
                    )

                # Comparación de nombres de nodos con nombre de tramo.
                n1_name = self._value_name(
                    n1_value
                )
                n2_name = self._value_name(
                    n2_value
                )

                tramo_name = self._normalize_name(
                    r["nombre"]
                )

                node_names = [
                    self._normalize_name(x)
                    for x in (
                        n1_name,
                        n2_name
                    )
                    if x
                ]

                if (
                    len(node_names) == 2
                    and not all(
                        name in tramo_name
                        for name in node_names
                    )
                ):
                    add(
                        "ADVERTENCIA",
                        "TRAMO_NOMBRE_NODOS_NO_COINCIDEN",
                        r,
                        (
                            "Los nombres recuperados de Nodo 1/Nodo 2 "
                            "no se identifican completamente en el "
                            "nombre del Tramo."
                        ),
                        (
                            "Revisar coherencia entre los extremos "
                            "del Tramo y su nomenclatura."
                        )
                    )

            # Conectividad por circuito
            for circuit in records:
                if circuit["tipo"].strip().lower() != "circuitos":
                    continue

                tramo_records = [
                    child
                    for child in children.get(
                        circuit["iid"],
                        []
                    )
                    if child["tipo"].strip().lower() == "tramos"
                ]

                edges = []

                for tramo in tramo_records:
                    n1, n2 = node_info.get(
                        tramo["iid"],
                        (
                            "",
                            ""
                        )
                    )

                    if n1 and n2:
                        edges.append(
                            (
                                n1,
                                n2,
                                tramo
                            )
                        )

                if len(edges) < 2:
                    continue

                graph = defaultdict(set)

                for n1, n2, _ in edges:
                    graph[n1].add(n2)
                    graph[n2].add(n1)

                unvisited = set(graph)
                components = 0

                while unvisited:
                    components += 1
                    stack = [
                        unvisited.pop()
                    ]

                    while stack:
                        node = stack.pop()

                        for neighbor in graph[node]:
                            if neighbor in unvisited:
                                unvisited.remove(
                                    neighbor
                                )
                                stack.append(
                                    neighbor
                                )

                if components > 1:
                    add(
                        "ERROR",
                        "CIRCUITO_TRAMOS_DESCONECTADOS",
                        circuit,
                        (
                            f"Los Tramos con información de nodos forman "
                            f"{components} grupos desconectados."
                        ),
                        (
                            "Los segmentos de un Circuito deben formar "
                            "una secuencia física continua."
                        )
                    )

        return findings




    # ========================================================
    # V12 - REGLAS DERIVADAS DEL MANUAL DE CREACIÓN BDATx
    # ========================================================

    @staticmethod
    def _strip_known_prefix(name, prefix):
        text = str(name or "").strip()
        pref = str(prefix or "").strip()
        if text.upper().startswith(pref.upper() + " "):
            return text[len(pref):].strip()
        return text

    @staticmethod
    def _contains_bad_decimal_comma(name):
        return bool(re.search(r"\d+,\d+", str(name or "")))

    @staticmethod
    def _contains_bad_kv_spacing_or_case(name):
        text = str(name or "")
        return bool(
            re.search(r"\d+\s+kV\b", text)
            or re.search(r"\d+K[Vv]\b", text)
            or re.search(r"\d+k[v]\b", text)
        )

    @staticmethod
    def _extract_nominal_voltage(name):
        match = re.search(
            r"(?<!\d)(\d+(?:\.\d+)?)kV\b",
            str(name or "")
        )
        return match.group(1) if match else ""

    @staticmethod
    def _extract_final_circuit_token(name):
        match = re.search(
            r"(?:^|\s)(C\d+)\s*$",
            str(name or "").strip().upper()
        )
        return match.group(1) if match else ""

    @staticmethod
    def _normalize_dash(text):
        return str(text or "").replace("–", "-").replace("—", "-")

    @staticmethod
    def _has_endpoint_separator(name):
        return bool(re.search(r"\s-\s", App._normalize_dash(name)))

    @staticmethod
    def _contains_forbidden_se_prefix_in_line_name(name):
        return bool(
            re.search(
                r"(?:^|\s)S/E(?:\s|$)",
                str(name or "").upper()
            )
        )

    def _dependants_proven(self, record):
        """
        True únicamente cuando /dependants/ respondió correctamente
        para el registro durante la carga actual.
        """
        evidence = self.dependants_evidence.get(
            (
                str(record.get("tipo", "")),
                str(record.get("id", ""))
            ),
            {}
        )
        return bool(evidence.get("ok"))


    @staticmethod
    def _is_empty_api_value(value):
        if value is None:
            return True

        if isinstance(value, str):
            return not value.strip()

        if isinstance(value, (list, tuple, set, dict)):
            return len(value) == 0

        return False


    @staticmethod
    def _canonical_name(text):
        """
        Normalización conservadora para comparar herencias sin generar
        errores por guiones tipográficos o espacios.
        """
        value = str(text or "")
        value = value.replace("–", "-").replace("—", "-")
        value = re.sub(r"\s*-\s*", " - ", value)
        value = re.sub(r"\s+", " ", value)
        return value.strip().upper()


    def _audit_rule_catalog(self):
        """
        Catálogo completo de reglas que esta versión puede detectar.
        Se utiliza también para reportar en Excel reglas con conteo = 0.
        """
        return [
            {
                "codigo": "ID_VACIO",
                "severidad": "ERROR",
                "aplica_a": "Todos",
                "descripcion": "Registro sin ID.",
                "criterio": "Todo registro debe poseer identificador."
            },
            {
                "codigo": "NOMBRE_VACIO",
                "severidad": "ERROR",
                "aplica_a": "Todos",
                "descripcion": "Registro sin Nombre.",
                "criterio": "El campo Nombre es obligatorio."
            },
            {
                "codigo": "PROPIETARIO_ID_VACIO",
                "severidad": "ERROR",
                "aplica_a": "Todos",
                "descripcion": "Registro sin Propietario ID.",
                "criterio": "Propietario es un campo obligatorio."
            },
            {
                "codigo": "PROPIETARIO_NOMBRE_VACIO",
                "severidad": "ADVERTENCIA",
                "aplica_a": "Todos",
                "descripcion": "No se pudo recuperar el nombre del propietario.",
                "criterio": "Revisar detalle individual del registro."
            },
            {
                "codigo": "NOMBRE_MINUSCULAS",
                "severidad": "ADVERTENCIA",
                "aplica_a": "Todos",
                "descripcion": "Nombre con minúsculas fuera de unidades toleradas.",
                "criterio": "La guía exige nombres en mayúsculas, respetando tildes."
            },
            {
                "codigo": "NOMBRE_DUPLICADO",
                "severidad": "ERROR",
                "aplica_a": "Mismo tipo",
                "descripcion": "Mismo Nombre utilizado por IDs distintos dentro del mismo tipo.",
                "criterio": "La guía define Nombre como único e irrepetible."
            },
            {
                "codigo": "REL_LINEA_CIRCUITO",
                "severidad": "ERROR",
                "aplica_a": "Línea",
                "descripcion": "Hijo directo de Línea que no es Circuito.",
                "criterio": "Circuito debe asociarse a su respectiva Línea."
            },
            {
                "codigo": "LINEA_SIN_CIRCUITOS",
                "severidad": "ERROR",
                "aplica_a": "Línea",
                "descripcion": "Línea sin ningún Circuito relacionado.",
                "criterio": "El contenedor principal Línea debe poseer el nivel siguiente Circuito."
            },
            {
                "codigo": "REL_CIRCUITO_TRAMO",
                "severidad": "ERROR",
                "aplica_a": "Circuito",
                "descripcion": "Hijo directo de Circuito que no es Tramo.",
                "criterio": "Tramo debe asociarse a su respectivo Circuito."
            },
            {
                "codigo": "CIRCUITO_SIN_TRAMO",
                "severidad": "ERROR",
                "aplica_a": "Circuito",
                "descripcion": "Circuito sin ningún Tramo relacionado.",
                "criterio": "La guía indica que todos los circuitos poseen al menos un tramo."
            },
            {
                "codigo": "CIRCUITO_SIN_C1",
                "severidad": "ERROR",
                "aplica_a": "Circuito",
                "descripcion": "Existe C2 o superior sin C1 bajo la misma Línea.",
                "criterio": "La guía prohíbe Circuito 2 o superior si no existe Circuito 1."
            },
            {
                "codigo": "TRAMO_CIRCUITO_NOMENCLATURA",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "La nomenclatura Cn del Tramo no coincide con el Circuito padre.",
                "criterio": (
                    "Si el Circuito padre es C1, el Tramo relacionado debe corresponder a C1; "
                    "si el Circuito padre es C2, el Tramo debe corresponder a C2. "
                    "Se valida el sufijo C1/C2 al final del nombre del Tramo."
                )
            },
            {
                "codigo": "REL_TRAMO_ATIPICA",
                "severidad": "ADVERTENCIA",
                "aplica_a": "Tramo",
                "descripcion": "Relación hija atípica bajo un Tramo.",
                "criterio": "Vano corresponde a tramo aéreo y Túnel al tramo subterráneo."
            },
            {
                "codigo": "TRAMO_SIN_INSTALACION",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "Tramo sin ninguna instalación del nivel siguiente.",
                "criterio": "El contenedor Tramo debe continuar con la instalación correspondiente: Vano si es aéreo o Túnel si es subterráneo."
            },
            {
                "codigo": "PREFIJO_NOMBRE",
                "severidad": "ADVERTENCIA",
                "aplica_a": "Línea/Circuito/Tramo/Vano/Accesorio",
                "descripcion": "Nombre no comienza con el prefijo normativo esperado.",
                "criterio": "Prefijos implementados: LT, CTO, TMO, VN y ACC."
            },
            {
                "codigo": "VANO_SIN_ACCESORIOS",
                "severidad": "ERROR",
                "aplica_a": "Vano",
                "descripcion": "Vano sin registro de Accesorios Vanos.",
                "criterio": "La guía indica que cada vano cuenta con un registro de accesorios vanos."
            },
            {
                "codigo": "TRAMO_SIN_CIRCUITO_CAMPO",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "No se detectó el campo obligatorio Circuito en el detalle.",
                "criterio": "El Tramo debe asociarse a su respectivo Circuito."
            },
            {
                "codigo": "TRAMO_SIN_NODO1",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "Tramo sin Nodo 1 detectable.",
                "criterio": "Nodo 1 es obligatorio para el Tramo."
            },
            {
                "codigo": "TRAMO_SIN_NODO2",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "Tramo sin Nodo 2 detectable.",
                "criterio": "Nodo 2 es obligatorio para el Tramo."
            },
            {
                "codigo": "TRAMO_SIN_DECRETO_NUP",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "Tramo sin Decreto/NUP detectable.",
                "criterio": "Decreto/NUP es obligatorio según la guía."
            },
            {
                "codigo": "TRAMO_SIN_CATEGORIA_VU",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "Tramo sin Categoría VU detectable.",
                "criterio": "Categoría VU es obligatoria según la guía."
            },
            {
                "codigo": "VANO_SIN_TRAMO_CAMPO",
                "severidad": "ERROR",
                "aplica_a": "Vano",
                "descripcion": "No se detectó el campo obligatorio Tramo en el detalle.",
                "criterio": "El Vano debe asociarse a su respectivo Tramo."
            },
            {
                "codigo": "VANO_SIN_NODO1",
                "severidad": "ERROR",
                "aplica_a": "Vano",
                "descripcion": "Vano sin Nodo 1 detectable.",
                "criterio": "Nodo 1 es obligatorio para el Vano."
            },
            {
                "codigo": "VANO_SIN_NODO2",
                "severidad": "ERROR",
                "aplica_a": "Vano",
                "descripcion": "Vano sin Nodo 2 detectable.",
                "criterio": "Nodo 2 es obligatorio para el Vano."
            },
            {
                "codigo": "VANO_SIN_DECRETO_NUP",
                "severidad": "ERROR",
                "aplica_a": "Vano",
                "descripcion": "Vano sin Decreto/NUP detectable.",
                "criterio": "Decreto/NUP es obligatorio según la guía."
            },
            {
                "codigo": "VANO_SIN_CATEGORIA_VU",
                "severidad": "ERROR",
                "aplica_a": "Vano",
                "descripcion": "Vano sin Categoría VU detectable.",
                "criterio": "Categoría VU es obligatoria según la guía."
            },
            {
                "codigo": "ACCESORIO_SIN_VANO_CAMPO",
                "severidad": "ERROR",
                "aplica_a": "Accesorios Vanos",
                "descripcion": "Accesorio sin campo Vano detectable.",
                "criterio": "El accesorio debe asociarse a su respectivo Vano."
            },
            {
                "codigo": "ACCESORIO_SIN_DECRETO_NUP",
                "severidad": "ERROR",
                "aplica_a": "Accesorios Vanos",
                "descripcion": "Accesorio sin Decreto/NUP detectable.",
                "criterio": "Decreto/NUP es obligatorio según la guía."
            },
            {
                "codigo": "ACCESORIO_SIN_CATEGORIA_VU",
                "severidad": "ERROR",
                "aplica_a": "Accesorios Vanos",
                "descripcion": "Accesorio sin Categoría VU detectable.",
                "criterio": "Categoría VU es obligatoria según la guía."
            },
            {
                "codigo": "TRAMO_CIRCUITO_ID_NO_COINCIDE",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "El Circuito del detalle no coincide con el Circuito padre.",
                "criterio": "Relación Circuito-Tramo inconsistente."
            },
            {
                "codigo": "VANO_TRAMO_ID_NO_COINCIDE",
                "severidad": "ERROR",
                "aplica_a": "Vano",
                "descripcion": "El Tramo del detalle no coincide con el Tramo padre.",
                "criterio": "Relación Tramo-Vano inconsistente."
            },
            {
                "codigo": "ACCESORIO_VANO_ID_NO_COINCIDE",
                "severidad": "ERROR",
                "aplica_a": "Accesorios Vanos",
                "descripcion": "El Vano del detalle no coincide con el Vano padre.",
                "criterio": "Relación Vano-Accesorio inconsistente."
            },
            {
                "codigo": "TRAMO_NODOS_IGUALES",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "Nodo 1 y Nodo 2 son el mismo registro.",
                "criterio": "Los extremos del Tramo deben ser distintos."
            },
            {
                "codigo": "TRAMO_NOMBRE_NODOS_NO_COINCIDEN",
                "severidad": "ADVERTENCIA",
                "aplica_a": "Tramo",
                "descripcion": "Los nombres de los nodos no se reflejan completamente en la nomenclatura del Tramo.",
                "criterio": "Revisión de coherencia de extremos."
            },
            {
                "codigo": "CIRCUITO_TRAMOS_DESCONECTADOS",
                "severidad": "ERROR",
                "aplica_a": "Circuito",
                "descripcion": "Los Tramos forman más de un componente desconectado.",
                "criterio": "Los segmentos de un Circuito deben formar una secuencia continua."
            },
            {
                "codigo": "LINEA_SIN_DECRETO_NUP",
                "severidad": "ERROR",
                "aplica_a": "Línea",
                "descripcion": "Línea sin Decreto/NUP detectable.",
                "criterio": "Decreto/NUP es obligatorio para Líneas de Transmisión."
            },
            {
                "codigo": "LINEA_SIN_SISTEMA_ELECTRICO",
                "severidad": "ERROR",
                "aplica_a": "Línea",
                "descripcion": "Línea sin Sistema eléctrico detectable.",
                "criterio": "Sistema eléctrico es obligatorio para Líneas de Transmisión."
            },
            {
                "codigo": "LINEA_SIN_CATEGORIA_VU",
                "severidad": "ERROR",
                "aplica_a": "Línea",
                "descripcion": "Línea sin Categoría VU detectable.",
                "criterio": "Categoría VU es obligatoria para Líneas de Transmisión."
            },
            {
                "codigo": "CIRCUITO_SIN_LINEA_CAMPO",
                "severidad": "ERROR",
                "aplica_a": "Circuito",
                "descripcion": "Circuito sin campo Línea detectable.",
                "criterio": "Línea es obligatoria para Circuitos."
            },
            {
                "codigo": "CIRCUITO_LINEA_ID_NO_COINCIDE",
                "severidad": "ERROR",
                "aplica_a": "Circuito",
                "descripcion": "El campo Línea del Circuito no coincide con la Línea padre.",
                "criterio": "El Circuito debe asociarse a su respectiva Línea."
            },
            {
                "codigo": "CIRCUITO_SIN_DECRETO_NUP",
                "severidad": "ERROR",
                "aplica_a": "Circuito",
                "descripcion": "Circuito sin Decreto/NUP detectable.",
                "criterio": "Decreto/NUP es obligatorio para Circuitos."
            },
            {
                "codigo": "CIRCUITO_SIN_CATEGORIA_VU",
                "severidad": "ERROR",
                "aplica_a": "Circuito",
                "descripcion": "Circuito sin Categoría VU detectable.",
                "criterio": "Categoría VU es obligatoria para Circuitos."
            },
            {
                "codigo": "TUNEL_SIN_TRAMO_CAMPO",
                "severidad": "ERROR",
                "aplica_a": "Túnel",
                "descripcion": "Túnel sin campo Tramo detectable.",
                "criterio": "Tramo es obligatorio para Túneles."
            },
            {
                "codigo": "TUNEL_TRAMO_ID_NO_COINCIDE",
                "severidad": "ERROR",
                "aplica_a": "Túnel",
                "descripcion": "El Tramo del detalle no coincide con el Tramo padre.",
                "criterio": "El Túnel debe asociarse a su respectivo Tramo."
            },
            {
                "codigo": "TUNEL_SIN_NODO1",
                "severidad": "ERROR",
                "aplica_a": "Túnel",
                "descripcion": "Túnel sin Nodo 1 detectable.",
                "criterio": "Nodo 1 es obligatorio para Túneles."
            },
            {
                "codigo": "TUNEL_SIN_NODO2",
                "severidad": "ERROR",
                "aplica_a": "Túnel",
                "descripcion": "Túnel sin Nodo 2 detectable.",
                "criterio": "Nodo 2 es obligatorio para Túneles."
            },
            {
                "codigo": "TUNEL_SIN_DECRETO_NUP",
                "severidad": "ERROR",
                "aplica_a": "Túnel",
                "descripcion": "Túnel sin Decreto/NUP detectable.",
                "criterio": "Decreto/NUP es obligatorio para Túneles."
            },
            {
                "codigo": "TUNEL_SIN_CATEGORIA_VU",
                "severidad": "ERROR",
                "aplica_a": "Túnel",
                "descripcion": "Túnel sin Categoría VU detectable.",
                "criterio": "Categoría VU es obligatoria para Túneles."
            },
            {
                "codigo": "NOMBRE_DECIMAL_CON_COMA",
                "severidad": "ERROR",
                "aplica_a": "Todos",
                "descripcion": "El Nombre utiliza coma como separador decimal.",
                "criterio": "El manual exige punto para valores decimales."
            },
            {
                "codigo": "LINEA_NOMBRE_SIN_SEPARADOR",
                "severidad": "ERROR",
                "aplica_a": "Línea",
                "descripcion": "Nombre de Línea sin separador entre extremos.",
                "criterio": "El formato LT exige extremo inicial - extremo final."
            },
            {
                "codigo": "LINEA_NOMBRE_SIN_TENSION",
                "severidad": "ERROR",
                "aplica_a": "Línea",
                "descripcion": "Nombre de Línea sin tensión nominal en formato kV.",
                "criterio": "El formato de Línea exige nivel de tensión."
            },
            {
                "codigo": "LINEA_NOMBRE_CONTIENE_SE",
                "severidad": "ERROR",
                "aplica_a": "Línea",
                "descripcion": "El Nombre de Línea contiene el prefijo S/E en un extremo.",
                "criterio": "Los extremos deben escribirse sin prefijo S/E."
            },
            {
                "codigo": "CIRCUITO_HERENCIA_LINEA_NO_COINCIDE",
                "severidad": "ERROR",
                "aplica_a": "Circuito",
                "descripcion": "La herencia del Nombre de Circuito no coincide con la Línea padre.",
                "criterio": "El Nombre de Circuito debe heredar el nombre de la Línea."
            },
            {
                "codigo": "CIRCUITO_SIN_NUMERO_NOMBRE",
                "severidad": "ERROR",
                "aplica_a": "Circuito",
                "descripcion": "Nombre de Circuito sin sufijo Cn.",
                "criterio": "El formato de Circuito exige Número Circuito."
            },
            {
                "codigo": "TRAMO_NOMBRE_SIN_SEPARADOR",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "Nombre de Tramo sin separador entre extremos.",
                "criterio": "El formato TMO exige Extremo 1 - Extremo 2."
            },
            {
                "codigo": "TRAMO_NOMBRE_SIN_CIRCUITO",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "Nombre de Tramo sin sufijo Cn.",
                "criterio": "El formato TMO exige Nombre Circuito."
            },
            {
                "codigo": "TRAMO_MEZCLA_VANO_TUNEL",
                "severidad": "ERROR",
                "aplica_a": "Tramo",
                "descripcion": "Un mismo Tramo contiene simultáneamente Vanos y Túneles.",
                "criterio": "El cambio aéreo/soterrado obliga a subdividir el circuito en otro Tramo."
            },
            {
                "codigo": "VANO_NOMBRE_SIN_DOS_PUNTOS",
                "severidad": "ERROR",
                "aplica_a": "Vano",
                "descripcion": "Nombre de Vano sin ':' entre extremos.",
                "criterio": "El formato VN exige separador ':' entre estructuras."
            },
            {
                "codigo": "VANO_EXTREMO_PREFIJO_INVALIDO",
                "severidad": "ADVERTENCIA",
                "aplica_a": "Vano",
                "descripcion": "El Vano no utiliza prefijos de estructura permitidos.",
                "criterio": "Los extremos del Vano deben usar TOR, POR, POS o ML."
            },
            {
                "codigo": "VANO_SIN_CIRCUITO_NOMBRE",
                "severidad": "ERROR",
                "aplica_a": "Vano",
                "descripcion": "Nombre de Vano sin sufijo Cn.",
                "criterio": "El formato VN exige Nombre Circuito."
            },
            {
                "codigo": "TUNEL_NOMBRE_SIN_DOS_PUNTOS",
                "severidad": "ERROR",
                "aplica_a": "Túnel",
                "descripcion": "Nombre de Túnel sin ':' entre extremos.",
                "criterio": "El formato TN exige separador ':' entre extremos."
            },
            {
                "codigo": "TUNEL_EXTREMO_PREFIJO_INVALIDO",
                "severidad": "ADVERTENCIA",
                "aplica_a": "Túnel",
                "descripcion": "El Túnel no utiliza prefijos CAM/PM en sus extremos.",
                "criterio": "Los extremos del Túnel deben usar CAM o PM."
            },
            {
                "codigo": "TUNEL_SIN_CIRCUITO_NOMBRE",
                "severidad": "ERROR",
                "aplica_a": "Túnel",
                "descripcion": "Nombre de Túnel sin sufijo Cn.",
                "criterio": "El formato TN exige Nombre Circuito."
            },
            {
                "codigo": "ACCESORIO_HERENCIA_VANO_NO_COINCIDE",
                "severidad": "ERROR",
                "aplica_a": "Accesorios Vanos",
                "descripcion": "El Nombre del Accesorio no hereda el Nombre del Vano padre.",
                "criterio": "El formato ACC exige herencia del Nombre del Vano."
            },
            {
                "codigo": "VANO_MULTIPLES_ACCESORIOS",
                "severidad": "ERROR",
                "aplica_a": "Vano",
                "descripcion": "Más de un registro Accesorios Vanos para un mismo Vano.",
                "criterio": "La guía indica un único registro de accesorios por cada vano."
            },
        ]


    def audit_records(self):
        records = self._tree_records_for_audit()
        findings = []
        if not records:
            return findings

        # Índice por IID para recuperar fácilmente el registro padre.
        by_iid = {
            r["iid"]: r
            for r in records
            if r.get("iid")
        }

        children = defaultdict(list)
        for r in records:
            children[r["parent_iid"]].append(r)

        def add(severity, code, record, message, rule):
            findings.append({
                "severidad": severity,
                "codigo": code,
                "nivel": record.get("nivel", ""),
                "tipo": record.get("tipo", ""),
                "id": record.get("id", ""),
                "nombre": record.get("nombre", ""),
                "propietario_id": record.get("propietario_id", ""),
                "padre": f'{record.get("parent_tipo","")} {record.get("parent_id","")} {record.get("parent_nombre","")}'.strip(),
                "mensaje": message,
                "regla": rule,
                "confianza": "ALTA" if severity == "ERROR" else "MEDIA",
                "iid": record.get("iid", "")
            })

        # Campos esenciales observables
        for r in records:
            if not r["id"].strip():
                add("ERROR", "ID_VACIO", r, "Registro sin ID.", "Todo registro debe poseer identificador.")
            if not r["nombre"].strip():
                add("ERROR", "NOMBRE_VACIO", r, "Registro sin nombre.", "El campo Nombre es obligatorio.")
            # Validar propietario usando primero el árbol ya enriquecido
            # y como respaldo el detalle individual recuperado por la auditoría.
            detail = self.audit_details.get(
                (
                    r["tipo"],
                    r["id"]
                ),
                {}
            )

            detail_owner_id, detail_owner_name = extract_owner(
                detail if isinstance(detail, dict) else {}
            )

            effective_owner_id = (
                r["propietario_id"].strip()
                or str(detail_owner_id or "").strip()
            )

            effective_owner_name = (
                r["propietario"].strip()
                or str(detail_owner_name or "").strip()
            )

            if not effective_owner_id:
                add(
                    "ERROR",
                    "PROPIETARIO_ID_VACIO",
                    r,
                    "No se obtuvo Propietario ID ni en el árbol ni en el detalle individual de la API.",
                    "Propietario es obligatorio."
                )

            if not effective_owner_name:
                add(
                    "ADVERTENCIA",
                    "PROPIETARIO_NOMBRE_VACIO",
                    r,
                    "No se obtuvo el nombre del propietario ni en el árbol ni en el detalle individual de la API.",
                    "Revisar el detalle individual."
                )
            if r["nombre"].strip() and not self._name_is_uppercase_conservative(r["nombre"]):
                add("ADVERTENCIA", "NOMBRE_MINUSCULAS", r, "El nombre contiene minúsculas fuera de unidades toleradas.", "La guía exige nombres en mayúsculas, respetando tildes.")

        # Mismo Tipo + ID bajo padres distintos
        id_groups = defaultdict(list)
        for r in records:
            key = (r["tipo"].strip().lower(), r["id"].strip())
            if key[0] and key[1]:
                id_groups[key].append(r)

        for _, group in id_groups.items():
            parents = {(g["parent_tipo"], g["parent_id"]) for g in group}

            # CORRECCIÓN V6:
            # En la jerarquía de Líneas, que un mismo registro aparezca en más
            # de una ruta/padre puede ser un relacionamiento válido.
            # Por lo tanto ID_MULTIPADRE NO se considera error para este módulo.
            #
            # Se conserva el agrupamiento únicamente como información interna
            # para futuras reglas específicas, pero no genera hallazgo.
            if len(parents) > 1:
                pass

        # Nombres duplicados dentro del mismo tipo
        name_groups = defaultdict(list)
        for r in records:
            n = self._normalize_name(r["nombre"])
            t = r["tipo"].strip().lower()
            if n and t:
                name_groups[(t, n)].append(r)

        for _, group in name_groups.items():
            ids = {g["id"] for g in group if g["id"]}
            if len(ids) > 1:
                for r in group:
                    add("ERROR", "NOMBRE_DUPLICADO", r,
                        f'Nombre repetido "{r["nombre"]}" con IDs {", ".join(sorted(ids))}.',
                        "La guía define el Nombre como único e irrepetible.")

        # Jerarquía Línea -> Circuito -> Tramo
        for r in records:
            p = r["parent_tipo"].strip().lower()
            c = r["tipo"].strip().lower()

            if p == "lineas" and c != "circuitos":
                add("ERROR", "REL_LINEA_CIRCUITO", r,
                    f'Una Línea contiene "{r["tipo"]}" en vez de Circuito.',
                    "Circuito debe asociarse a su respectiva Línea.")

            if p == "circuitos" and c != "tramos":
                add("ERROR", "REL_CIRCUITO_TRAMO", r,
                    f'Un Circuito contiene "{r["tipo"]}" en vez de Tramo.',
                    "Tramo debe asociarse a su respectivo Circuito.")

            if p == "tramos":
                allowed = {"vanos", "tuneles", "estaciones-repetidoras"}
                if c and c not in allowed:
                    add("ADVERTENCIA", "REL_TRAMO_ATIPICA", r,
                        f'El Tramo contiene "{r["tipo"]}". Validar la relación.',
                        "Vano corresponde a tramo aéreo y Túnel es homólogo para tramo subterráneo.")

        # Toda Línea principal debe tener al menos un Circuito
        for r in records:
            if r["tipo"].strip().lower() == "lineas":
                circuit_children = [
                    c for c in children.get(r["iid"], [])
                    if c["tipo"].strip().lower() == "circuitos"
                ]

                if (
                    self.loaded_depth >= 1
                    and self._dependants_proven(r)
                    and not circuit_children
                ):
                    add(
                        "ERROR",
                        "LINEA_SIN_CIRCUITOS",
                        r,
                        "Línea sin ningún Circuito relacionado; falta el nivel siguiente.",
                        "El contenedor principal Línea debe poseer al menos un Circuito."
                    )

        # Todo circuito posee al menos un tramo
        for r in records:
            if r["tipo"].strip().lower() == "circuitos":
                tramo_children = [c for c in children.get(r["iid"], []) if c["tipo"].strip().lower() == "tramos"]
                if (
                    self.loaded_depth >= 2
                    and self._dependants_proven(r)
                    and not tramo_children
                ):
                    add("ERROR", "CIRCUITO_SIN_TRAMO", r,
                        "Circuito sin ningún tramo relacionado.",
                        "La guía indica que todos los circuitos poseen al menos un tramo.")

        # C2 o superior sin C1
        for line in records:
            if line["tipo"].strip().lower() != "lineas":
                continue
            circuitos = [c for c in children.get(line["iid"], []) if c["tipo"].strip().lower() == "circuitos"]
            nums = []
            for c in circuitos:
                m = re.search(r"\bC(?:IRCUITO\s*)?(\d+)\b", self._normalize_name(c["nombre"]))
                if m:
                    nums.append((int(m.group(1)), c))
            if nums and any(n >= 2 for n, _ in nums) and not any(n == 1 for n, _ in nums):
                for n, c in nums:
                    if n >= 2:
                        add("ERROR", "CIRCUITO_SIN_C1", c,
                            "Se detectó Circuito 2 o superior sin Circuito 1 bajo la misma línea.",
                            "La guía prohíbe C2 o superior si no existe C1.")

        # --------------------------------------------------------
        # Coherencia de nomenclatura Circuito -> Tramo
        #
        # Ejemplo:
        # Circuito ... C1 no debe contener un Tramo cuyo nombre
        # termine en C2, y viceversa.
        #
        # Se toma la designación FINAL C1/C2 del nombre del Tramo.
        # Esto evita confundir referencias intermedias a C1/C2 que
        # puedan formar parte de la descripción física del tramo.
        # --------------------------------------------------------
        def final_circuit_designator(name):
            text = str(name or "").strip().upper()

            match = re.search(
                r"(?:^|[\s\-\(\)])(C\d+)\s*$",
                text
            )

            return match.group(1) if match else ""


        def circuit_designator(name):
            text = str(name or "").strip().upper()

            match = re.search(
                r"(?:^|[\s\-\(\)])(C\d+)\s*$",
                text
            )

            if match:
                return match.group(1)

            # Fallback para nombres de circuito donde C1/C2 aparece
            # como token pero no estrictamente al final.
            tokens = re.findall(
                r"(?<![A-Z0-9])C(\d+)(?![A-Z0-9])",
                text
            )

            if tokens:
                return "C" + tokens[-1]

            return ""


        for r in records:
            if r["tipo"].strip().lower() != "tramos":
                continue

            parent = by_iid.get(
                r.get("parent_iid", "")
            )

            if not parent:
                continue

            if parent["tipo"].strip().lower() != "circuitos":
                continue

            parent_circuit = circuit_designator(
                parent["nombre"]
            )

            tramo_circuit = final_circuit_designator(
                r["nombre"]
            )

            if (
                parent_circuit
                and tramo_circuit
                and parent_circuit != tramo_circuit
            ):
                add(
                    "ERROR",
                    "TRAMO_CIRCUITO_NOMENCLATURA",
                    r,
                    (
                        f'Error de relacionamiento por nomenclatura: '
                        f'el Circuito padre "{parent["nombre"]}" es '
                        f'{parent_circuit}, pero el Tramo '
                        f'"{r["nombre"]}" termina en {tramo_circuit}.'
                    ),
                    (
                        "La designación C1/C2 del Tramo debe coincidir "
                        "con la designación C1/C2 del Circuito padre."
                    )
                )

        # Todo Tramo debe continuar con una instalación del nivel siguiente.
        # Para tramo aéreo se espera Vano; para subterráneo, Túnel.
        # Se valida existencia de al menos una instalación hija.
        for r in records:
            if r["tipo"].strip().lower() == "tramos":
                next_children = children.get(r["iid"], [])

                if (
                    self.loaded_depth >= 3
                    and self._dependants_proven(r)
                    and not next_children
                ):
                    add(
                        "ERROR",
                        "TRAMO_SIN_INSTALACION",
                        r,
                        (
                            "Tramo sin instalaciones relacionadas en el nivel siguiente; "
                            "falta Vano para tramo aéreo o Túnel para tramo subterráneo."
                        ),
                        (
                            "El contenedor Tramo debe continuar con la instalación "
                            "correspondiente al tipo de tramo."
                        )
                    )

        # Prefijos de nombre
        prefixes = {
            "lineas": "LT ",
            "circuitos": "CTO ",
            "tramos": "TMO ",
            "vanos": "VN ",
            "accesorios-vanos": "ACC "
        }

        for r in records:
            expected = prefixes.get(r["tipo"].strip().lower())
            if expected and r["nombre"].strip():
                if not self._normalize_name(r["nombre"]).startswith(expected.strip() + " "):
                    add("ADVERTENCIA", "PREFIJO_NOMBRE", r,
                        f'El nombre no comienza con el prefijo esperado "{expected.strip()}".',
                        "Formato de nombre definido por la guía.")

        # Un registro de accesorios por vano
        accessory_types = {"accesorios-vanos", "accesorios_vanos", "accesoriosvanos"}
        for r in records:
            if r["tipo"].strip().lower() != "vanos":
                continue
            acc = [c for c in children.get(r["iid"], []) if c["tipo"].strip().lower() in accessory_types]
            if (
                self.loaded_depth >= 4
                and self._dependants_proven(r)
                and len(acc) == 0
            ):
                add("ERROR", "VANO_SIN_ACCESORIOS", r,
                    "Vano sin registro de Accesorios Vanos; falta la instalación del nivel siguiente.",
                    "La guía indica que cada vano cuenta con un registro de accesorios vanos.")
            elif len(acc) > 1:
                add("ERROR", "VANO_MULTIPLES_ACCESORIOS", r,
                    f"Se detectaron {len(acc)} registros de Accesorios Vanos.",
                    "La guía indica un único registro de accesorios por cada vano.")

        severity_order = {"ERROR": 0, "ADVERTENCIA": 1, "INFO": 2}
        findings.sort(key=lambda x: (
            severity_order.get(x["severidad"], 9),
            x["nivel"] if isinstance(x["nivel"], int) else 99,
            x["tipo"],
            x["id"]
        ))
        return findings

    def run_audit(self):
        if not self.tree.get_children(""):
            messagebox.showinfo(
                "Auditoría",
                "Primero cargue un árbol de relacionamiento."
            )
            return

        records = self._tree_records_for_audit()
        base = self.base_var.get().strip()
        workers = self._settings_snapshot().get(
            "workers",
            8
        )

        # Separar exploración rápida de auditoría profunda:
        # recién aquí se consultan los detalles individuales.
        self._start_loading(
            f"Preparando auditoría profunda de "
            f"{len(records)} registros..."
        )

        threading.Thread(
            target=self._prepare_audit_details_worker,
            args=(
                base,
                records,
                workers
            ),
            daemon=True
        ).start()


    def _finish_audit_after_details(
        self,
        details
    ):
        self.audit_details = details or {}

        # Antes de ejecutar reglas base, completar Propietario/Nombre
        # desde el detalle individual de la API.
        enriched_owner_records = self._enrich_tree_from_audit_details()

        self._finish_loading()

        try:
            findings = self.audit_records()

            findings = self._append_deep_audit_findings(
                findings,
                self._tree_records_for_audit()
            )

            self.status_var.set(
                f"Auditoría procesada. {enriched_owner_records} registro(s) enriquecido(s) desde Detalles API."
            )

            # V13: eliminar duplicados exactos de hallazgos.
            unique_findings = []
            seen_findings = set()

            for finding in findings:
                key = (
                    finding.get("codigo", ""),
                    finding.get("tipo", ""),
                    finding.get("id", ""),
                    finding.get("mensaje", "")
                )

                if key not in seen_findings:
                    seen_findings.add(key)
                    unique_findings.append(finding)

            findings = unique_findings

            severity_order = {
                "ERROR": 0,
                "ADVERTENCIA": 1,
                "INFO": 2
            }

            findings.sort(
                key=lambda x: (
                    severity_order.get(
                        x["severidad"],
                        9
                    ),
                    x["nivel"]
                    if isinstance(
                        x["nivel"],
                        int
                    )
                    else 99,
                    x["tipo"],
                    x["id"],
                    x["codigo"]
                )
            )

        except Exception as exc:
            messagebox.showerror(
                "Error en auditoría",
                (
                    "Ocurrió un error al ejecutar "
                    "las reglas de auditoría.\n\n"
                    f"{type(exc).__name__}: {exc}"
                )
            )
            return

        report_path = None
        report_error = None

        try:
            report_path = self._generate_audit_excel(
                findings
            )
        except Exception as exc:
            report_error = (
                f"{type(exc).__name__}: {exc}"
            )

        try:
            self._open_audit_window(
                findings,
                report_path=report_path,
                report_error=report_error
            )
        except Exception as exc:
            messagebox.showerror(
                "Error mostrando auditoría",
                (
                    "La auditoría se ejecutó, pero no "
                    "fue posible mostrar la ventana.\n\n"
                    f"{type(exc).__name__}: {exc}"
                )
            )


    def _audit_line_label(self):
        ids = [
            str(x).strip()
            for x in getattr(self, "loaded_line_ids", [])
            if str(x).strip()
        ]

        if not ids:
            current = self.line_var.get().strip()
            return current or "SIN_ID"

        if len(ids) == 1:
            return ids[0]

        if len(ids) <= 5:
            return "MULTI_" + "_".join(ids)

        return f"MULTI_{len(ids)}_LINEAS"


    def _generate_audit_excel(self, findings):
        """
        Genera un reporte Excel automático de la auditoría.

        Ubicación:
        ~/Documents/Reportes_BDATx/

        Contenido:
        - Resumen
        - Hallazgos
        - Árbol Auditado
        """
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
            from openpyxl.utils import get_column_letter
        except Exception as exc:
            raise RuntimeError(
                "No se encuentra openpyxl. Regenere el EXE con build_windows_v5.bat."
            ) from exc

        line_id = self._audit_line_label()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Guardar reportes automáticamente en Descargas.
        downloads = Path.home() / "Downloads"

        if not downloads.exists():
            downloads = Path.home()

        report_dir = downloads / "Reportes_BDATx"
        report_dir.mkdir(parents=True, exist_ok=True)

        filename = f"Auditoria_BDATx_Linea_{line_id}_{timestamp}.xlsx"
        path = report_dir / filename

        wb = Workbook()

        # ====================================================
        # HOJA RESUMEN
        # ====================================================
        ws = wb.active
        ws.title = "Resumen"

        errors = sum(
            1 for x in findings
            if x["severidad"] == "ERROR"
        )
        warnings = sum(
            1 for x in findings
            if x["severidad"] == "ADVERTENCIA"
        )

        tree_rows = self._tree_records_for_audit()
        total_records = len(tree_rows)

        owner_id = self.owner_id_var.get().strip()
        owner_name = self.owner_name_var.get().strip()

        ws["A1"] = "REPORTE DE AUDITORÍA DE RELACIONAMIENTO BDATx"
        ws["A1"].font = Font(bold=True, size=16)
        ws.merge_cells("A1:D1")

        summary_rows = [
            ("Línea ID", line_id),
            ("Fecha de auditoría", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            ("Propietario ID", owner_id),
            ("Propietario", owner_name),
            ("Registros auditados", total_records),
            ("Errores", errors),
            ("Advertencias", warnings),
            ("Total hallazgos", len(findings)),
            ("Resultado", "CON HALLAZGOS" if findings else "SIN HALLAZGOS"),
        ]

        start = 3
        for idx, (label, value) in enumerate(summary_rows, start=start):
            ws.cell(row=idx, column=1, value=label)
            ws.cell(row=idx, column=2, value=value)
            ws.cell(row=idx, column=1).font = Font(bold=True)

        ws["A14"] = "Interpretación"
        ws["A14"].font = Font(bold=True)

        ws["A15"] = (
            "ERROR: incumplimiento detectable con la información cargada. "
            "ADVERTENCIA: condición que requiere revisión porque la API puede no "
            "exponer todas las relaciones o campos."
        )
        ws.merge_cells("A15:D17")
        ws["A15"].alignment = Alignment(wrap_text=True, vertical="top")

        # Resumen por código: incluye TODAS las reglas detectables,
        # incluso cuando la cantidad es cero.
        ws["A19"] = "Hallazgos por código"
        ws["A19"].font = Font(bold=True)

        ws.append(["Código", "Severidad", "Cantidad", "Descripción"])

        counters = {}
        for f in findings:
            key = (f["codigo"], f["severidad"])
            counters[key] = counters.get(key, 0) + 1

        for rule in self._audit_rule_catalog():
            codigo = rule["codigo"]
            severidad = rule["severidad"]
            cantidad = counters.get((codigo, severidad), 0)

            ws.append([
                codigo,
                severidad,
                cantidad,
                rule["descripcion"]
            ])

        ws.column_dimensions["A"].width = 34
        ws.column_dimensions["B"].width = 30
        ws.column_dimensions["C"].width = 18
        ws.column_dimensions["D"].width = 65

        # ====================================================
        # HOJA CATÁLOGO DE ERRORES / REGLAS
        # ====================================================
        wc = wb.create_sheet("Catalogo Errores")

        catalog_headers = [
            "Código",
            "Severidad",
            "Aplica a",
            "Descripción",
            "Criterio de validación",
            "Cantidad detectada"
        ]

        wc.append(catalog_headers)

        rule_counts = {}
        for f in findings:
            key = (f["codigo"], f["severidad"])
            rule_counts[key] = rule_counts.get(key, 0) + 1

        for rule in self._audit_rule_catalog():
            wc.append([
                rule["codigo"],
                rule["severidad"],
                rule["aplica_a"],
                rule["descripcion"],
                rule["criterio"],
                rule_counts.get(
                    (rule["codigo"], rule["severidad"]),
                    0
                )
            ])

        # ====================================================
        # HOJA DETALLES API
        # ====================================================
        wd = wb.create_sheet("Detalles API")

        wd.append([
            "Tipo",
            "ID",
            "Campo",
            "Valor"
        ])

        for (
            tipo,
            item_id
        ), detail in sorted(
            self.audit_details.items()
        ):
            if not isinstance(detail, dict):
                continue

            for key, value in detail.items():
                if isinstance(
                    value,
                    (
                        dict,
                        list
                    )
                ):
                    try:
                        value_text = json.dumps(
                            value,
                            ensure_ascii=False
                        )
                    except Exception:
                        value_text = str(
                            value
                        )
                else:
                    value_text = str(
                        value
                    )

                wd.append([
                    tipo,
                    item_id,
                    key,
                    value_text
                ])

        # ====================================================
        # HOJA NO EVALUABLES
        # ====================================================
        wn = wb.create_sheet("No Evaluables")

        wn.append([
            "Código",
            "Tipo",
            "ID",
            "Nombre",
            "Motivo"
        ])

        for item in self.not_evaluable:
            wn.append([
                item.get("codigo", ""),
                item.get("tipo", ""),
                item.get("id", ""),
                item.get("nombre", ""),
                item.get("motivo", "")
            ])

        if not self.not_evaluable:
            wn.append([
                "OK",
                "",
                "",
                "",
                "No hubo reglas no evaluables."
            ])

        # ====================================================
        # HOJA HALLAZGOS
        # ====================================================
        wh = wb.create_sheet("Hallazgos")

        headers = [
            "Severidad",
            "Código",
            "Nivel",
            "Tipo",
            "ID",
            "Nombre",
            "Propietario ID",
            "Padre",
            "Hallazgo",
            "Regla",
            "Confianza"
        ]

        wh.append(headers)

        for f in findings:
            wh.append([
                f["severidad"],
                f["codigo"],
                f["nivel"],
                f["tipo"],
                f["id"],
                f["nombre"],
                f["propietario_id"],
                f["padre"],
                f["mensaje"],
                f["regla"],
                f.get("confianza", "")
            ])

        if not findings:
            wh.append([
                "OK",
                "SIN_HALLAZGOS",
                "",
                "",
                "",
                "",
                "",
                "",
                "No se detectaron anomalías con las reglas implementadas.",
                ""
            ])

        # ====================================================
        # HOJA ÁRBOL AUDITADO
        # ====================================================
        wt = wb.create_sheet("Arbol Auditado")

        tree_headers = [
            "Nivel",
            "Tipo",
            "ID",
            "Nombre",
            "Propietario ID",
            "Propietario",
            "Tipo Padre",
            "ID Padre",
            "Nombre Padre"
        ]

        wt.append(tree_headers)

        for r in tree_rows:
            wt.append([
                r["nivel"],
                r["tipo"],
                r["id"],
                r["nombre"],
                r["propietario_id"],
                r["propietario"],
                r["parent_tipo"],
                r["parent_id"],
                r["parent_nombre"]
            ])

        # ====================================================
        # FORMATO PROFESIONAL
        # ====================================================
        header_fill = PatternFill("solid", fgColor="1F4E78")
        header_font = Font(color="FFFFFF", bold=True)
        error_fill = PatternFill("solid", fgColor="F4CCCC")
        warning_fill = PatternFill("solid", fgColor="FFF2CC")
        ok_fill = PatternFill("solid", fgColor="D9EAD3")
        thin = Side(style="thin", color="D9D9D9")

        for sheet in (wc, wd, wn, wh, wt):
            for cell in sheet[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(
                    horizontal="center",
                    vertical="center"
                )

            sheet.freeze_panes = "A2"
            sheet.auto_filter.ref = sheet.dimensions

            for row in sheet.iter_rows():
                for cell in row:
                    cell.border = Border(
                        bottom=thin
                    )
                    cell.alignment = Alignment(
                        vertical="top",
                        wrap_text=True
                    )

        # Formato de severidad
        for row in range(2, wh.max_row + 1):
            severity = str(
                wh.cell(row=row, column=1).value or ""
            ).upper()

            if severity == "ERROR":
                fill = error_fill
            elif severity == "ADVERTENCIA":
                fill = warning_fill
            else:
                fill = ok_fill

            for col in range(1, wh.max_column + 1):
                wh.cell(row=row, column=col).fill = fill

        # Anchos Detalles API
        details_widths = [28, 16, 32, 80]
        for idx, width in enumerate(
            details_widths,
            start=1
        ):
            wd.column_dimensions[
                get_column_letter(idx)
            ].width = width

        # Anchos Catálogo
        catalog_widths = [28, 16, 28, 55, 75, 20]
        for idx, width in enumerate(catalog_widths, start=1):
            wc.column_dimensions[
                get_column_letter(idx)
            ].width = width

        # Color por severidad en catálogo
        for row in range(2, wc.max_row + 1):
            severity = str(
                wc.cell(row=row, column=2).value or ""
            ).upper()

            fill = (
                error_fill
                if severity == "ERROR"
                else warning_fill
                if severity == "ADVERTENCIA"
                else ok_fill
            )

            for col in range(1, wc.max_column + 1):
                wc.cell(row=row, column=col).fill = fill

        # Anchos No Evaluables
        no_eval_widths = [30, 25, 15, 45, 80]
        for idx, width in enumerate(no_eval_widths, start=1):
            wn.column_dimensions[
                get_column_letter(idx)
            ].width = width

        # Anchos Hallazgos
        hallazgos_widths = [
            15, 26, 9, 24, 14, 45, 20, 42, 70, 70, 14
        ]
        for idx, width in enumerate(hallazgos_widths, start=1):
            wh.column_dimensions[
                get_column_letter(idx)
            ].width = width

        # Anchos árbol
        tree_widths = [
            9, 26, 14, 48, 20, 42, 26, 14, 48
        ]
        for idx, width in enumerate(tree_widths, start=1):
            wt.column_dimensions[
                get_column_letter(idx)
            ].width = width

        # Encabezado Resumen
        for cell in ws["A1:D1"][0]:
            cell.fill = header_fill
            cell.font = Font(
                color="FFFFFF",
                bold=True,
                size=16
            )

        # KPI con colores
        for row in range(start, start + len(summary_rows)):
            label = str(ws.cell(row=row, column=1).value or "")

            if label == "Errores":
                ws.cell(row=row, column=2).fill = error_fill
            elif label == "Advertencias":
                ws.cell(row=row, column=2).fill = warning_fill
            elif label == "Resultado":
                ws.cell(row=row, column=2).fill = (
                    error_fill
                    if findings
                    else ok_fill
                )

        wb.save(path)

        return str(path)


    def _open_audit_window(self, findings, report_path=None, report_error=None):
        win = tk.Toplevel(self)
        win.title("Auditoría de relacionamiento BDATx")
        win.geometry("1500x720")
        win.minsize(1050, 520)
        win.transient(self)

        errors = sum(1 for x in findings if x["severidad"] == "ERROR")
        warnings = sum(1 for x in findings if x["severidad"] == "ADVERTENCIA")

        header = ttk.Frame(win, padding=(10, 10, 10, 6))
        header.pack(fill="x")
        ttk.Label(
            header,
            text=f"Auditoría Línea(s) {self._audit_line_label()}",
            font=("Segoe UI", 11, "bold")
        ).pack(side="left")
        ttk.Label(
            header,
            text=f"{errors} error(es) | {warnings} advertencia(s) | {len(findings)} hallazgo(s)"
        ).pack(side="right")

        ttk.Label(
            win,
            text=(
                "Errores = incumplimientos detectables con el árbol cargado. "
                "Advertencias = requieren revisión porque la API puede no exponer todas las relaciones."
            ),
            padding=(10, 0, 10, 8)
        ).pack(fill="x")


        report_bar = ttk.Frame(
            win,
            padding=(10, 0, 10, 8)
        )
        report_bar.pack(fill="x")

        if report_path:

            ttk.Label(
                report_bar,
                text="Reporte Excel generado correctamente."
            ).pack(side="left")

            def open_excel_report():
                try:
                    import os
                    os.startfile(report_path)
                except Exception as exc:
                    messagebox.showerror(
                        "Abrir reporte Excel",
                        f"No fue posible abrir el reporte:\n\n{exc}"
                    )

            ttk.Button(
                report_bar,
                text="Abrir reporte Excel",
                command=open_excel_report
            ).pack(side="left", padx=(12, 0))

        elif report_error:

            ttk.Label(
                report_bar,
                text=f"No fue posible generar el reporte Excel: {report_error}"
            ).pack(side="left")

        body = ttk.Frame(win, padding=(10, 0, 10, 6))
        body.pack(fill="both", expand=True)

        cols = ("sev", "codigo", "confianza", "nivel", "tipo", "id", "nombre", "pid", "padre", "mensaje")
        tv = ttk.Treeview(body, columns=cols, show="headings", selectmode="browse")

        heads = {
            "sev": "Severidad", "codigo": "Código", "confianza": "Confianza", "nivel": "Nivel",
            "tipo": "Tipo", "id": "ID", "nombre": "Nombre",
            "pid": "Propietario ID", "padre": "Padre", "mensaje": "Hallazgo"
        }
        for c, h in heads.items():
            tv.heading(c, text=h)

        widths = {
            "sev": 105, "codigo": 190, "confianza": 90, "nivel": 65, "tipo": 180,
            "id": 90, "nombre": 300, "pid": 120, "padre": 260, "mensaje": 540
        }
        for c, w in widths.items():
            tv.column(c, width=w, stretch=(c in {"nombre", "mensaje", "padre"}))

        tv.tag_configure("ERROR", background="#FDECEC")
        tv.tag_configure("ADVERTENCIA", background="#FFF7DD")

        sy = ttk.Scrollbar(body, orient="vertical", command=tv.yview)
        sx = ttk.Scrollbar(body, orient="horizontal", command=tv.xview)
        tv.configure(yscrollcommand=sy.set, xscrollcommand=sx.set)
        tv.grid(row=0, column=0, sticky="nsew")
        sy.grid(row=0, column=1, sticky="ns")
        sx.grid(row=1, column=0, sticky="ew")
        body.rowconfigure(0, weight=1)
        body.columnconfigure(0, weight=1)

        for idx, f in enumerate(findings):
            tv.insert(
                "", "end", iid=f"AUD_{idx}",
                values=(
                    f["severidad"], f["codigo"], f.get("confianza", ""), f["nivel"], f["tipo"],
                    f["id"], f["nombre"], f["propietario_id"],
                    f["padre"], f["mensaje"]
                ),
                tags=(f["severidad"],)
            )

        if not findings:
            tv.insert("", "end", values=(
                "OK", "SIN_HALLAZGOS", "", "", "", "", "", "",
                "No se detectaron anomalías con las reglas implementadas."
            ))

        actions = ttk.Frame(win, padding=(10, 4, 10, 10))
        actions.pack(fill="x")

        def go_to_record():
            sel = tv.selection()
            if not sel or not sel[0].startswith("AUD_"):
                return
            idx = int(sel[0].split("_", 1)[1])
            source_iid = findings[idx].get("iid")
            if source_iid and self.tree.exists(source_iid):
                parent = self.tree.parent(source_iid)
                while parent:
                    self.tree.item(parent, open=True)
                    parent = self.tree.parent(parent)
                self.tree.selection_set(source_iid)
                self.tree.focus(source_iid)
                self.tree.see(source_iid)

        def export_audit_csv():
            path = filedialog.asksaveasfilename(
                title="Exportar auditoría a CSV",
                defaultextension=".csv",
                initialfile=f"Auditoria_ArbolLinea_{self._audit_line_label()}.csv",
                filetypes=[("Archivo CSV", "*.csv")]
            )
            if not path:
                return
            with open(path, "w", newline="", encoding="utf-8-sig") as fh:
                writer = csv.writer(fh, delimiter=";")
                writer.writerow([
                    "Severidad", "Código", "Nivel", "Tipo", "ID", "Nombre",
                    "Propietario ID", "Padre", "Hallazgo", "Regla"
                ])
                for f in findings:
                    writer.writerow([
                        f["severidad"], f["codigo"], f["nivel"], f["tipo"],
                        f["id"], f["nombre"], f["propietario_id"], f["padre"],
                        f["mensaje"], f["regla"]
                    ])
            messagebox.showinfo("Auditoría", f"Auditoría exportada:\\n\\n{path}")

        ttk.Button(
            actions,
            text="Ir al registro",
            command=go_to_record
        ).pack(side="left")

        if report_path:
            def open_report_folder():
                try:
                    import os
                    os.startfile(str(Path(report_path).parent))
                except Exception as exc:
                    messagebox.showerror(
                        "Abrir carpeta",
                        f"No fue posible abrir la carpeta:\n\n{exc}"
                    )

            ttk.Button(
                actions,
                text="Abrir carpeta de reportes",
                command=open_report_folder
            ).pack(side="left", padx=(8, 0))

        ttk.Button(
            actions,
            text="Exportar auditoría CSV",
            command=export_audit_csv
        ).pack(side="right")

        ttk.Button(
            actions,
            text="Cerrar",
            command=win.destroy
        ).pack(side="right", padx=(0, 8))
        tv.bind("<Double-1>", lambda e: go_to_record())


    # ========================================================
    # EXPORTACIÓN CSV / EXCEL
    # ========================================================

    def _rows_for_export(self):
        rows = []

        def walk(parent=""):
            for item in self.tree.get_children(parent):
                values = self.tree.item(item, "values")
                relation = self.tree.item(item, "text")

                rows.append([
                    relation,
                    values[0] if len(values) > 0 else "",
                    values[1] if len(values) > 1 else "",
                    values[2] if len(values) > 2 else "",
                    values[3] if len(values) > 3 else "",
                    values[4] if len(values) > 4 else "",
                    values[5] if len(values) > 5 else ""
                ])

                walk(item)

        walk()
        return rows


    def export_csv(self):
        rows = self._rows_for_export()

        if not rows:
            messagebox.showinfo(
                "Exportar CSV",
                "Primero cargue un árbol de relacionamiento."
            )
            return

        line_id = self.line_var.get().strip() or "linea"

        path = filedialog.asksaveasfilename(
            title="Exportar árbol a CSV",
            defaultextension=".csv",
            initialfile=f"ArbolLinea_{line_id}.csv",
            filetypes=[
                ("Archivo CSV", "*.csv"),
                ("Todos los archivos", "*.*")
            ]
        )

        if not path:
            return

        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                writer = csv.writer(f, delimiter=";")
                writer.writerow([
                    "Relación",
                    "Nivel",
                    "Tipo",
                    "ID",
                    "Nombre",
                    "Propietario ID",
                    "Propietario"
                ])
                writer.writerows(rows)

            messagebox.showinfo(
                "Exportar CSV",
                f"Archivo exportado correctamente:\\n\\n{path}"
            )

        except Exception as exc:
            messagebox.showerror(
                "Exportar CSV",
                f"No fue posible crear el archivo:\\n\\n{exc}"
            )


    def export_excel(self):
        rows = self._rows_for_export()

        if not rows:
            messagebox.showinfo(
                "Exportar Excel",
                "Primero cargue un árbol de relacionamiento."
            )
            return

        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, Alignment
            from openpyxl.utils import get_column_letter
        except Exception:
            messagebox.showerror(
                "Exportar Excel",
                "No se encontró el componente de Excel (openpyxl).\\n\\n"
                "Vuelva a generar el EXE usando build_windows.bat."
            )
            return

        line_id = self.line_var.get().strip() or "linea"

        path = filedialog.asksaveasfilename(
            title="Exportar árbol a Excel",
            defaultextension=".xlsx",
            initialfile=f"ArbolLinea_{line_id}.xlsx",
            filetypes=[
                ("Libro de Excel", "*.xlsx"),
                ("Todos los archivos", "*.*")
            ]
        )

        if not path:
            return

        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "Relacionamiento"

            headers = [
                "Relación",
                "Nivel",
                "Tipo",
                "ID",
                "Nombre",
                "Propietario ID",
                "Propietario"
            ]

            ws.append(headers)

            for row in rows:
                ws.append(row)

            # Encabezado legible y autofiltro.
            for cell in ws[1]:
                cell.font = Font(bold=True)
                cell.alignment = Alignment(horizontal="center")

            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions

            widths = [18, 10, 28, 14, 48, 20, 42]

            for idx, width in enumerate(widths, start=1):
                ws.column_dimensions[get_column_letter(idx)].width = width

            wb.save(path)

            messagebox.showinfo(
                "Exportar Excel",
                f"Archivo exportado correctamente:\\n\\n{path}"
            )

        except Exception as exc:
            messagebox.showerror(
                "Exportar Excel",
                f"No fue posible crear el archivo:\\n\\n{exc}"
            )


    # ========================================================
    # AUXILIARES
    # ========================================================

    def _count_items(self):
        n = 0

        def walk(parent=""):
            nonlocal n
            for item in self.tree.get_children(parent):
                n += 1
                walk(item)

        walk()

        return n


    def find_next(self):
        term = self.search_var.get().strip().lower()

        if not term:
            return

        items = []

        def collect(parent=""):
            for item in self.tree.get_children(parent):
                items.append(item)
                collect(item)

        collect()

        if not items:
            messagebox.showinfo(
                "Buscar",
                "Primero cargue una línea."
            )
            return

        current = self.tree.selection()
        start = 0

        if current and current[0] in items:
            start = items.index(current[0]) + 1

        for item in items[start:] + items[:start]:
            values = self.tree.item(item, "values")

            if term in " ".join(map(str, values)).lower():
                parent = self.tree.parent(item)

                while parent:
                    self.tree.item(parent, open=True)
                    parent = self.tree.parent(parent)

                self.tree.selection_set(item)
                self.tree.focus(item)
                self.tree.see(item)
                return

        messagebox.showinfo(
            "Buscar",
            "No se encontraron coincidencias."
        )


if __name__ == "__main__":
    App().mainloop()
