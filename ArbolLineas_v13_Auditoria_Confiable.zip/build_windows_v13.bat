@echo off
setlocal
title Generar ArbolLineas V13

echo ===========================================================
echo   ARBOLLINEAS V13 - AUDITORIA CONFIABLE
echo ===========================================================
echo.

py -m pip install --upgrade pip
if errorlevel 1 goto ERROR

py -m pip install pyinstaller openpyxl
if errorlevel 1 goto ERROR

pyinstaller ^
  --noconfirm ^
  --clean ^
  --onefile ^
  --windowed ^
  --name ArbolLineasAuditoriaV13 ^
  --collect-all openpyxl ^
  arbol_lineas_v13_auditoria_confiable.py

if errorlevel 1 goto ERROR

echo.
echo EXE generado en:
echo %CD%\dist\ArbolLineasAuditoriaV13.exe
echo.
pause
exit /b 0

:ERROR
echo.
echo Ocurrio un error durante la compilacion.
pause
exit /b 1
